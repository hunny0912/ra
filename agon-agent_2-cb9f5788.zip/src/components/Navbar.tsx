import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { CalendarCheck, Menu, Phone, X, MessageCircle, Clock } from 'lucide-react';
import { CLINIC, isOpenNow } from '../lib/store';

const LINKS = [
  { to: '/', label: 'Home' },
  { to: '/services', label: 'Treatments' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const openNow = isOpenNow();

  useEffect(() => {
    setOpen(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  return (
    <header className="sticky top-0 z-50">
      {/* Top info bar */}
      <div className="bg-pine text-cream/85 text-[11px] sm:text-[11.5px]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-8 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className="relative flex h-2 w-2 shrink-0">
              {openNow && <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 animate-ping-dot" />}
              <span className={`relative inline-flex h-2 w-2 rounded-full ${openNow ? 'bg-emerald-400' : 'bg-red-400'}`} />
            </span>
            <span className="font-semibold text-cream truncate">{openNow ? 'Open now' : 'Closed'} · 10:30 AM – 7:00 PM</span>
            <span className="hidden md:inline text-cream/40">|</span>
            <span className="hidden md:inline truncate">Sanskriti Arcade, Chatrapati Chowk Rd, Wakad</span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a href={CLINIC.phoneHref} className="flex items-center gap-1.5 font-semibold hover:text-gold transition-colors">
              <Phone size={11} strokeWidth={2.5} /> 092841 31821
            </a>
            <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 font-semibold text-[#7CE3A8] hover:text-[#a5f0c4] transition-colors">
              <MessageCircle size={12} strokeWidth={2.5} /> WhatsApp
            </a>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div className={`transition-all duration-300 border-b ${
        scrolled ? 'bg-cream/90 backdrop-blur-xl border-pine/10 shadow-[0_8px_30px_-18px_rgb(20_60_51/0.4)]' : 'bg-cream border-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-2.5 shrink-0 group">
            <img src="/favicon.svg" alt="Lazy Hair and Skin Clinic logo" className="h-10 w-10 transition-transform duration-500 group-hover:rotate-[15deg]" />
            <span className="leading-tight">
              <span className="block font-display font-bold text-[17px] sm:text-lg text-pine tracking-tight">Lazy <span className="text-terra">Hair</span> &amp; Skin</span>
              <span className="block text-[9px] sm:text-[9.5px] font-sans font-semibold uppercase tracking-[0.16em] text-moss">Dermatology Clinic · Wakad</span>
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {LINKS.map((l) => (
              <NavLink key={l.to} to={l.to}
                className={({ isActive }) => `px-4 py-2 rounded-full text-[13.5px] font-semibold transition-all ${
                  isActive ? 'bg-pine text-cream' : 'text-ink/75 hover:text-pine hover:bg-sand'
                }`}>
                {l.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/book')}
              className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-terra px-4 py-2.5 text-[13px] font-bold text-cream shadow-card hover:bg-terra-dark transition-colors">
              <CalendarCheck size={15} strokeWidth={2.5} /> Book Visit
            </button>
            <button className="lg:hidden p-2 text-pine" onClick={() => setOpen((v) => !v)} aria-label={open ? 'Close menu' : 'Open menu'}>
              {open ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        <AnimatePresence>
          {open && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 top-[104px] bg-pine/40 backdrop-blur-sm z-40 lg:hidden" onClick={() => setOpen(false)} />
              <motion.div
                initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}
                transition={{ type: 'spring', stiffness: 380, damping: 34 }}
                className="absolute left-0 right-0 top-full bg-cream border-b border-pine/10 shadow-soft z-50 lg:hidden">
                <div className="px-5 py-5">
                  <nav className="grid gap-1">
                    {LINKS.map((l) => (
                      <NavLink key={l.to} to={l.to}
                        className={({ isActive }) => `flex items-center justify-between rounded-xl px-4 py-3.5 font-semibold text-[15px] ${
                          isActive ? 'bg-pine text-cream' : 'text-ink hover:bg-sand'
                        }`}>
                        {l.label}
                        <span className="text-lg opacity-40">→</span>
                      </NavLink>
                    ))}
                  </nav>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <a href={CLINIC.phoneHref} className="flex items-center justify-center gap-2 rounded-xl border border-pine/20 px-4 py-3 text-sm font-bold text-pine">
                      <Phone size={16} /> Call Now
                    </a>
                    <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3 text-sm font-bold text-pine">
                      <MessageCircle size={16} /> WhatsApp
                    </a>
                  </div>
                  <button onClick={() => navigate('/book')} className="mt-2 w-full flex items-center justify-center gap-2 rounded-xl bg-terra px-4 py-3.5 font-bold text-cream">
                    <CalendarCheck size={17} /> Book Appointment — Free
                  </button>
                  <p className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-ink/55">
                    <Clock size={11} /> Open daily · 10:30 AM – 7:00 PM · Sanskriti Arcade, Wakad
                  </p>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
