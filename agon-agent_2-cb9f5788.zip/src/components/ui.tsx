import { Star, StarHalf } from 'lucide-react';

export function Stars({ rating, size = 15 }: { rating: number; size?: number }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.4 && rating - full < 0.9;
  return (
    <span className="inline-flex items-center gap-[2px]" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }, (_, i) => {
        if (i < full) return <Star key={i} size={size} className="fill-gold text-gold" />;
        if (i === full && half)
          return (
            <span key={i} className="relative inline-block" style={{ width: size, height: size }}>
              <Star size={size} className="absolute inset-0 text-gold/50" />
              <StarHalf size={size} className="absolute inset-0 fill-gold text-gold" />
            </span>
          );
        return <Star key={i} size={size} className="text-gold/40" />;
      })}
    </span>
  );
}

export function SectionHeading({
  eyebrow, title, sub, align = 'center', dark = false,
}: { eyebrow: string; title: React.ReactNode; sub?: string; align?: 'center' | 'left'; dark?: boolean }) {
  const alignCls = align === 'center' ? 'items-center text-center mx-auto' : 'items-start text-left';
  return (
    <div className={`flex flex-col ${alignCls} max-w-2xl`}>
      <span className={`inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] ${
        dark ? 'border-cream/20 text-gold' : 'border-pine/15 text-terra bg-sand'
      }`}>
        <span className="h-1.5 w-1.5 rounded-full bg-terra animate-pulse" />
        {eyebrow}
      </span>
      <h2 className={`mt-4 font-display font-semibold text-[clamp(1.75rem,4.2vw,2.6rem)] leading-[1.08] tracking-tight ${dark ? 'text-cream' : 'text-pine'}`}>
        {title}
      </h2>
      {sub && <p className={`mt-3 text-[15px] leading-relaxed ${dark ? 'text-cream/70' : 'text-ink/70'}`}>{sub}</p>}
    </div>
  );
}

export function PageHero({ eyebrow, title, sub }: { eyebrow: string; title: React.ReactNode; sub: string }) {
  return (
    <div className="relative overflow-hidden bg-pine grain">
      <div aria-hidden className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-pine-800 blur-3xl opacity-70" />
      <div aria-hidden className="absolute -bottom-40 -right-24 h-[28rem] w-[28rem] rounded-full bg-terra/15 blur-3xl" />
      <div aria-hidden className="absolute right-[12%] top-10 hidden lg:block opacity-30 animate-spin-slow">
        <svg width="150" height="150" viewBox="0 0 150 150" fill="none">
          <circle cx="75" cy="75" r="70" stroke="#C99A5B" strokeWidth="1" strokeDasharray="3 7" />
          <circle cx="75" cy="75" r="46" stroke="#C99A5B" strokeWidth="1" strokeDasharray="3 7" />
        </svg>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-14 sm:pt-20 sm:pb-16">
        <span className="inline-flex items-center gap-2 rounded-full border border-cream/15 bg-cream/5 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-gold">
          {eyebrow}
        </span>
        <h1 className="mt-4 font-display font-semibold text-cream text-[clamp(2rem,5.5vw,3.4rem)] leading-[1.05] tracking-tight max-w-3xl">
          {title}
        </h1>
        <p className="mt-4 text-cream/70 max-w-xl text-[15px] sm:text-base leading-relaxed">{sub}</p>
      </div>
      <svg aria-hidden viewBox="0 0 1440 32" className="block w-full text-cream" preserveAspectRatio="none"><path fill="currentColor" d="M0,32 L0,14 C240,2 480,26 720,18 C960,10 1200,4 1440,16 L1440,32 Z" /></svg>
    </div>
  );
}
