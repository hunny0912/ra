import { Link, useNavigate } from 'react-router-dom';
import { Phone, MapPin, Clock, MessageCircle, Star, Navigation, Instagram, Facebook, Youtube, Heart } from 'lucide-react';
import { CLINIC } from '../lib/store';

export default function Footer() {
  const navigate = useNavigate();
  return (
    <footer className="bg-pine text-cream relative grain">
      {/* Giant wordmark */}
      <div aria-hidden className="pointer-events-none select-none overflow-hidden border-t border-cream/10">
        <p className="font-display font-black text-[15.5vw] lg:text-[11rem] leading-[0.9] text-cream/[0.045] whitespace-nowrap text-center translate-y-[18%]">
          LAZY · HAIR &amp; SKIN
        </p>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-6">
        <div className="grid lg:grid-cols-12 gap-10">
          {/* Brand */}
          <div className="lg:col-span-3">
            <Link to="/" className="flex items-center gap-2.5">
              <img src="/favicon.svg" alt="" className="h-11 w-11" />
              <span className="font-display font-bold text-lg leading-tight">Lazy <span className="text-gold">Hair</span> &amp; Skin<br /><span className="text-[10px] font-sans font-semibold uppercase tracking-[0.18em] text-cream/60">Dermatology Clinic · Wakad</span></span>
            </Link>
            <p className="mt-4 text-sm text-cream/65 leading-relaxed">Wakad &amp; Pimpri-Chinchwad’s most loved dermatology clinic — honest advice, medical precision and treatments that actually deliver.</p>
            <div className="mt-4 flex items-center gap-2 rounded-xl border border-cream/10 bg-cream/5 px-3 py-2 w-fit">
              <Star size={15} className="fill-gold text-gold" />
              <span className="text-sm font-bold">5.0</span>
              <span className="text-xs text-cream/60">· 8 Google reviews · 100% recommend</span>
            </div>
            <div className="mt-4 flex items-center gap-2">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a key={i} href={CLINIC.mapsLink} target="_blank" rel="noreferrer" aria-label="Social profile"
                  className="p-2.5 rounded-full border border-cream/15 text-cream/75 hover:text-pine hover:bg-gold hover:border-gold transition-all">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Treatments */}
          <div className="lg:col-span-2">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold">Treatments</p>
            <ul className="mt-3 space-y-2 text-[13px] text-cream/70">
              {['PRP Hair Therapy', 'Laser Hair Removal', 'Hydrafacial', 'Chemical Peels', 'Acne & Scars', 'Botox & Fillers'].map((s) => (
                <li key={s}><button onClick={() => navigate('/services')} className="hover:text-cream transition-colors">{s}</button></li>
              ))}
            </ul>
          </div>

          {/* Quick links */}
          <div className="lg:col-span-2">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold">Clinic</p>
            <ul className="mt-3 space-y-2 text-[13px] text-cream/70">
              <li><Link to="/about" className="hover:text-cream transition-colors">About the Doctor</Link></li>
              <li><Link to="/reviews" className="hover:text-cream transition-colors">Patient Reviews</Link></li>
              <li><Link to="/book" className="hover:text-cream transition-colors">Book Appointment</Link></li>
              <li><Link to="/my-appointments" className="hover:text-cream transition-colors">My Appointments</Link></li>
              <li><Link to="/contact" className="hover:text-cream transition-colors">FAQs & Contact</Link></li>
            </ul>
          </div>

          {/* Visit */}
          <div className="lg:col-span-5">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold">Visit Us</p>
            <ul className="mt-3 space-y-3 text-[13px] text-cream/75">
              <li className="flex items-start gap-2.5">
                <MapPin size={16} className="mt-0.5 shrink-0 text-terra" />
                <span>Sanskriti Arcade, 205, Chatrapati Chowk Rd, opp. PCMC School,<br />Kaspate Wasti, Wakad, Pimpri-Chinchwad,<br />Maharashtra 411057</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock size={16} className="shrink-0 text-terra" /> Mon–Sun · 10:30 AM – 7:00 PM (no lunch break)
              </li>
              <li className="flex items-center gap-2.5">
                <Phone size={16} className="shrink-0 text-terra" />
                <a href={CLINIC.phoneHref} className="font-bold text-cream hover:text-gold transition-colors">092841 31821</a>
              </li>
              <li className="flex items-center gap-2.5">
                <Navigation size={16} className="shrink-0 text-terra" /> Plus Code: {CLINIC.plusCode}
              </li>
            </ul>
            <div className="mt-4 flex flex-wrap gap-2">
              <a href={CLINIC.mapsLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-cream text-pine px-4 py-2 text-xs font-bold hover:bg-gold-soft transition-colors"><Navigation size={12} /> Get Directions</a>
              <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full bg-[#25D366] text-pine px-4 py-2 text-xs font-bold hover:brightness-110 transition"><MessageCircle size={12} /> WhatsApp Us</a>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-cream/10 pt-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-cream/50">
          <p>© {new Date().getFullYear()} Lazy Hair and Skin Clinic (लेजी हेयर एंड स्किन क्लिनिक). All rights reserved.</p>
          <p className="flex items-center gap-1.5">Made for healthy skin <Heart size={11} className="fill-terra text-terra" /> Wakad, Pune 411057</p>
        </div>
      </div>
    </footer>
  );
}
