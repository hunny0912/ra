import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { BadgeCheck, PenLine, Star, X, ThumbsUp, MessageSquareText, Sparkles } from 'lucide-react';
import { REVIEWS, SERVICE_OPTIONS, type Review } from '../data/reviews';
import { useToast } from '../lib/Toast';
import { PageHero, Stars } from '../components/ui';

export default function Reviews() {
  const toast = useToast();
  const [userReviews, setUserReviews] = useState<Review[]>([]);
  const [filter, setFilter] = useState<string>('All');
  const [sort, setSort] = useState<'recent' | 'helpful'>('recent');
  const [helpful, setHelpful] = useState<Record<number, number>>({});
  const [helpedIds, setHelpedIds] = useState<Set<number>>(new Set());
  const [formOpen, setFormOpen] = useState(false);

  // form state
  const [fName, setFName] = useState('');
  const [fRating, setFRating] = useState(5);
  const [fService, setFService] = useState(SERVICE_OPTIONS[0]);
  const [fText, setFText] = useState('');
  const [fTouched, setFTouched] = useState(false);

  const all = useMemo(() => [...userReviews, ...REVIEWS], [userReviews]);
  const filtered = useMemo(() => {
    let list = filter === 'All' ? all : all.filter(r => r.service === filter);
    if (sort === 'helpful') list = [...list].sort((a, b) => (helpful[b.id] ?? 0) - (helpful[a.id] ?? 0));
    else list = [...list].sort((a, b) => b.date.localeCompare(a.date));
    return list;
  }, [all, filter, sort, helpful]);

  const submit = () => {
    setFTouched(true);
    if (fName.trim().length < 2 || fText.trim().length < 12) return;
    const initials = fName.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('');
    setUserReviews(p => [{
      id: Date.now(), name: fName.trim(), initials, date: new Date().toISOString().slice(0, 10),
      rating: fRating, service: fService, text: fText.trim(), color: '#C4552D', verified: false,
    }, ...p]);
    setFormOpen(false);
    setFName(''); setFText(''); setFRating(5); setFTouched(false);
    toast({ kind: 'success', title: 'Thank you!', desc: 'Your review has been published on this page.' });
  };

  const markHelpful = (id: number) => {
    if (helpedIds.has(id)) return;
    setHelpful(p => ({ ...p, [id]: (p[id] ?? 0) + 1 }));
    setHelpedIds(p => new Set(p).add(id));
  };

  return (
    <div className="bg-cream">
      <PageHero eyebrow="Patient Reviews" title={<><span className="text-gold">5.0 ★</span> from real<br />Google patients</>} sub="Every review below comes from a verified Google visit to Lazy Hair and Skin Clinic, Wakad. No paid endorsements — ever." />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
        {/* Rating summary */}
        <div className="grid sm:grid-cols-12 gap-4 items-stretch">
          <div className="sm:col-span-4 rounded-3xl bg-pine text-cream p-6 flex flex-col items-center justify-center text-center shadow-soft">
            <p className="font-display font-black text-6xl">5.0</p>
            <Stars rating={5} size={19} />
            <p className="mt-2 text-[11px] font-bold uppercase tracking-[0.18em] text-cream/60">8 Google reviews</p>
            <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-gold/15 text-gold text-[10.5px] font-extrabold px-3 py-1.5"><Sparkles size={12} />100% of patients recommend</p>
          </div>
          <div className="sm:col-span-5 rounded-3xl border border-pine/12 bg-sand p-6 flex flex-col justify-center">
            {[5, 4, 3, 2, 1].map(n => (
              <div key={n} className="flex items-center gap-2.5 py-[3px]">
                <span className="text-[12px] font-bold text-ink/70 w-3">{n}</span>
                <Star size={13} className="fill-gold text-gold shrink-0" />
                <div className="h-2.5 flex-1 rounded-full bg-shell overflow-hidden"><div className="h-full bg-gold rounded-full" style={{ width: n === 5 ? '100%' : '0%' }} /></div>
                <span className="text-[11px] font-semibold text-ink/55 w-6 text-right">{n === 5 ? 8 : 0}</span>
              </div>
            ))}
          </div>
          <div className="sm:col-span-3 rounded-3xl border border-gold/40 bg-gold-soft p-6 flex flex-col items-center justify-center text-center">
            <p className="font-display font-bold text-lg text-pine leading-snug">Visited us recently?</p>
            <button onClick={() => setFormOpen(true)} className="mt-3 inline-flex items-center gap-2 rounded-full bg-terra text-cream px-5 py-2.5 text-[12.5px] font-extrabold hover:bg-terra-dark transition-colors"><PenLine size={15} /> Write a review</button>
          </div>
        </div>

        {/* Controls */}
        <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
            {['All', ...SERVICE_OPTIONS].map(s => (
              <button key={s} onClick={() => setFilter(s)}
                className={`whitespace-nowrap rounded-full px-3.5 h-9 text-[11.5px] font-bold border transition-all ${filter === s ? 'bg-pine text-cream border-pine' : 'bg-sand text-pine border-pine/15'}`}>{s}</button>
            ))}
          </div>
          <div className="flex items-center gap-1.5 text-[12px] font-bold text-ink/60 shrink-0">
            Sort:
            {(['recent', 'helpful'] as const).map(o => (
              <button key={o} onClick={() => setSort(o)} className={`rounded-full px-3 h-9 border capitalize transition-all ${sort === o ? 'bg-terra text-cream border-terra' : 'border-pine/20 text-pine'}`}>{o}</button>
            ))}
          </div>
        </div>

        {/* Review cards */}
        <div className="mt-5 grid md:grid-cols-2 gap-4">
          {filtered.map(r => (
            <figure key={r.id} className="rounded-3xl border border-pine/12 bg-sand p-5 sm:p-6 flex flex-col hover:shadow-card transition-shadow">
              <div className="flex items-center justify-between gap-2">
                <Stars rating={r.rating} size={14} />
                <span className="text-[10px] font-semibold text-ink/50">{new Date(r.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
              </div>
              <blockquote className="mt-3 text-[13px] leading-relaxed text-ink/85 flex-1">“{r.text}”</blockquote>
              <figcaption className="mt-4 pt-4 border-t border-pine/10 flex items-center gap-3">
                <span className="h-10 w-10 rounded-full flex items-center justify-center text-cream text-[12px] font-extrabold shrink-0" style={{ background: r.color }}>{r.initials}</span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1.5 text-[12.5px] font-bold text-pine">{r.name}{r.verified && <BadgeCheck size={13} className="text-sky-700 shrink-0" />}</span>
                  <span className="block text-[10.5px] text-ink/55">{r.service}</span>
                </span>
                <button onClick={() => markHelpful(r.id)} aria-label="Mark review helpful"
                  className={`flex flex-col items-center gap-0.5 rounded-xl px-2.5 py-1.5 transition-all ${helpedIds.has(r.id) ? 'bg-pine text-cream' : 'text-ink/55 hover:bg-shell/60'}`}>
                  <ThumbsUp size={15} />
                  <span className="text-[9.5px] font-bold">{helpful[r.id] ?? 0}</span>
                </button>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>

      {/* Write review modal */}
      <AnimatePresence>
        {formOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] bg-pine/70 backdrop-blur-sm" onClick={() => setFormOpen(false)} />
            <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 50 }} role="dialog" aria-modal="true" aria-label="Write a review"
              className="fixed z-[61] inset-x-3 bottom-3 sm:inset-auto sm:left-1/2 sm:top-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 sm:w-[min(520px,94vw)] bg-cream rounded-3xl shadow-soft p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-xl text-pine flex items-center gap-2"><MessageSquareText size={20} className="text-terra" />Share your experience</h3>
                <button onClick={() => setFormOpen(false)} aria-label="Close" className="p-2 rounded-full hover:bg-sand"><X size={20} /></button>
              </div>
              <label className="block mt-4 text-[11px] font-bold text-ink/70">Your name *
                <input value={fName} onChange={e => setFName(e.target.value)} placeholder="e.g. Aditi Sharma" className={`mt-1.5 w-full h-11 rounded-xl bg-sand px-4 outline-none border-2 ${fTouched && fName.trim().length < 2 ? 'border-red-400' : 'border-transparent focus:border-terra'}`} />
              </label>
              <div className="mt-3 flex items-center gap-4">
                <div>
                  <p className="text-[11px] font-bold text-ink/70">Your rating</p>
                  <div className="mt-1 flex gap-1">
                    {[1,2,3,4,5].map(n => (
                      <button key={n} onClick={() => setFRating(n)} aria-label={`${n} star${n > 1 ? 's' : ''}`}>
                        <Star size={28} className={n <= fRating ? 'fill-gold text-gold' : 'text-shell'} strokeWidth={1.5} />
                      </button>
                    ))}
                  </div>
                </div>
                <label className="flex-1 text-[11px] font-bold text-ink/70">Treatment
                  <select value={fService} onChange={e => setFService(e.target.value)} className="mt-1.5 w-full h-10 rounded-xl bg-sand px-3 outline-none border-2 border-transparent focus:border-terra text-[12.5px] font-medium">
                    {SERVICE_OPTIONS.map(s => <option key={s}>{s}</option>)}
                  </select>
                </label>
              </div>
              <label className="block mt-3 text-[11px] font-bold text-ink/70">Your review * <span className="font-semibold text-ink/45">(min 12 characters)</span>
                <textarea value={fText} onChange={e => setFText(e.target.value)} rows={4} placeholder="How was your experience with Dr. Sneha and the team?" className={`mt-1.5 w-full rounded-xl bg-sand p-4 outline-none border-2 text-[13px] leading-relaxed ${fTouched && fText.trim().length < 12 ? 'border-red-400' : 'border-transparent focus:border-terra'}`} />
              </label>
              {fTouched && fText.trim().length < 12 && <p className="mt-1 text-[11px] text-red-600 font-semibold">Please write at least 12 characters.</p>}
              <button onClick={submit} className="mt-4 w-full rounded-2xl bg-terra py-4 font-extrabold text-cream hover:bg-terra-dark transition-colors">Publish review</button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
