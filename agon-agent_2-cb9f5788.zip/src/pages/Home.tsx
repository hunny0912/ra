import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowRight, ArrowLeft, Phone, Star, CalendarCheck, Sparkles, BadgeCheck,
  ShieldCheck, IndianRupee, ChevronDown, MapPin, Clock, CheckCircle2, MessageCircle, Stethoscope,
} from 'lucide-react';
import { SERVICES } from '../data/services';
import { REVIEWS } from '../data/reviews';
import { CLINIC, isOpenNow } from '../lib/store';
import { SectionHeading, Stars } from '../components/ui';

const HERO_SLIDES = [
  { src: '/images/facial-treatment.jpg', label: 'Signature Hydrafacial' },
  { src: '/images/consultation.jpg', label: 'Private Consultations' },
  { src: '/images/treatment-room.jpg', label: 'Laser Suite, Wakad' },
];

const MARQUEE = ['PRP Hair Therapy', 'Laser Hair Removal', 'Hydrafacial', 'Chemical Peels', 'Acne & Scar Revision', 'Carbon Laser Facial', 'Botox & Fillers', 'Mesotherapy'];

const STATS = [
  { value: '5.0', suffix: '★', label: 'Google Rating' },
  { value: '2400', suffix: '+', label: 'Happy Patients' },
  { value: '8', suffix: ' yrs', label: 'Dermatology Practice' },
  { value: '100', suffix: '%', label: 'Would Recommend Us' },
];

const WHY = [
  { icon: Stethoscope, title: 'Doctor-led, always', text: 'Every plan — from peels to PRP — is personally designed by an MD dermatologist, never delegated blindly.' },
  { icon: IndianRupee, title: 'Honest, transparent pricing', text: 'No package traps or surprise bills. Consultation fee adjustable against any treatment.' },
  { icon: ShieldCheck, title: 'Medical-grade safety', text: 'FDA-approved machines, single-use sterile disposables and proper patch testing, every time.' },
  { icon: BadgeCheck, title: 'Realistic expectations', text: 'We’d rather tell you a peel won’t fix deep scars than sell you a fantasy. That honesty shows.' },
];

const FAQS = [
  { q: 'Do I need an appointment, or can I walk in?', a: 'Walk-ins are welcome between 10:30 AM and 7:00 PM, but booked patients are seen first. We recommend booking online or on WhatsApp to skip the wait.' },
  { q: 'Is the consultation fee adjusted against procedures?', a: 'Yes. Your ₹500 consultation fee is fully adjusted against any procedure or treatment you take on the same visit.' },
  { q: 'How many sessions will PRP hair therapy actually take?', a: 'Most patients notice reduced hair fall after 2–3 sessions and visible thickening after 4–6 sessions spaced 4–6 weeks apart. We assess honestly at every visit — if it isn’t working for you, we tell you.' },
  { q: 'What is laser hair removal like on Indian skin?', a: 'We use triple-wavelength diode lasers tuned for Fitzpatrick III–V skin. Sensation is like a warm rubber-band snap, and the sapphire cooling tip keeps it very comfortable. 6–8 sessions typically give 90%+ reduction.' },
  { q: 'Where exactly are you located in Wakad?', a: 'Sanskriti Arcade, 2nd floor, Shop 205, Chatrapati Chowk Road, opposite PCMC School, Kaspate Wasti — 2 minutes from Wakad junction, with parking available at the arcade. Plus code: HQWF+2G.' },
];

function AnimatedStat({ value, suffix, label }: { value: string; suffix: string; label: string }) {
  const numeric = parseFloat(value);
  const isDecimal = value.includes('.');
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        const dur = 1400, start = performance.now();
        const tick = (t: number) => {
          const p = Math.min((t - start) / dur, 1);
          const eased = 1 - Math.pow(2, -8 * p);
          setShown(numeric * (p === 1 ? 1 : eased));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        io.disconnect();
      }
    }, { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, [numeric]);
  return (
    <div ref={ref} className="text-center">
      <p className="font-display font-bold text-3xl sm:text-4xl text-pine tracking-tight">
        {isDecimal ? shown.toFixed(1) : Math.round(shown).toLocaleString('en-IN')}<span className="text-terra">{suffix}</span>
      </p>
      <p className="mt-1 text-[11px] sm:text-xs font-semibold uppercase tracking-[0.14em] text-moss">{label}</p>
    </div>
  );
}

function BeforeAfter() {
  const [pos, setPos] = useState(56);
  const boxRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const move = (clientX: number) => {
    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect) return;
    setPos(Math.min(96, Math.max(4, ((clientX - rect.left) / rect.width) * 100)));
  };
  const onPointerDown = (e: React.PointerEvent) => {
    dragging.current = true;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    move(e.clientX);
  };
  useEffect(() => {
    const onMove = (e: PointerEvent) => { if (dragging.current) move(e.clientX); };
    const onUp = () => { dragging.current = false; };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => { window.removeEventListener('pointermove', onMove); window.removeEventListener('pointerup', onUp); };
  }, []);

  return (
    <div
      ref={boxRef}
      onPointerDown={onPointerDown}
      role="slider" aria-label="Before and after comparison" aria-valuenow={Math.round(pos)} aria-valuemin={0} aria-valuemax={100} tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'ArrowLeft') setPos(p => Math.max(4, p - 5)); if (e.key === 'ArrowRight') setPos(p => Math.min(96, p + 5)); }}
      className="relative w-full select-none overflow-hidden rounded-3xl shadow-soft cursor-ew-resize touch-none aspect-[4/5] sm:aspect-[4/4.6]"
    >
      {/* AFTER — healthy */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#F7D9C4] via-[#F2BFD3] to-[#E8A98F] flex flex-col items-center justify-center">
        <svg viewBox="0 0 120 150" className="h-44 w-36 sm:h-52 sm:w-44" role="img" aria-label="Clear, glowing skin">
          <ellipse cx="60" cy="72" rx="44" ry="56" fill="#F8CFBA" />
          <path d="M28 44 Q60 6 92 44 L92 30 Q60 0 28 30 Z" fill="#3B2A22" />
          <ellipse cx="60" cy="122" rx="26" ry="12" fill="#F8CFBA" />
          <path d="M46 130 L34 148 H86 L74 130 Z" fill="#EAF3EC" opacity="0.9" />
          <circle cx="44" cy="70" r="3.1" fill="#33241D" /><circle cx="76" cy="70" r="3.1" fill="#33241D" />
          <path d="M36 60 Q44 57 52 60 M68 60 Q76 57 84 60" stroke="#33241D" strokeWidth="1.6" fill="none" strokeLinecap="round" />
          <path d="M42 92 Q60 106 78 92" stroke="#B4552D" strokeWidth="2.6" fill="none" strokeLinecap="round" />
          <circle cx="33" cy="82" r="3.4" fill="#F0A48A" opacity="0.7" /><circle cx="87" cy="82" r="3.4" fill="#F0A48A" opacity="0.7" />
        </svg>
        <span className="absolute bottom-5 right-5 rounded-full bg-pine/85 backdrop-blur px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-gold">After · 8 weeks</span>
      </div>
      {/* BEFORE — acne */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#CBB6A6] via-[#B9A08F] to-[#9E887A] flex flex-col items-center justify-center" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <svg viewBox="0 0 120 150" className="h-44 w-36 sm:h-52 sm:w-44" role="img" aria-label="Skin with acne, before treatment">
          <ellipse cx="60" cy="72" rx="44" ry="56" fill="#D8BDa9" />
          <path d="M28 44 Q60 6 92 44 L92 30 Q60 0 28 30 Z" fill="#40302A" />
          <ellipse cx="60" cy="122" rx="26" ry="12" fill="#D8BDA9" />
          <path d="M46 130 L34 148 H86 L74 130 Z" fill="#EDE6DA" opacity="0.85" />
          <circle cx="44" cy="70" r="3" fill="#33241D" /><circle cx="76" cy="70" r="3" fill="#33241D" />
          <path d="M36 61 Q44 58.5 52 61 M68 61 Q76 58.5 84 61" stroke="#33241D" strokeWidth="1.5" fill="none" strokeLinecap="round" />
          {[[40,52],[66,46],[54,66],[78,84],[38,86],[62,88],[48,100],[72,60]].map(([x,y],i) => (
            <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 2.6 : 1.9} fill="#7E4B38" opacity="0.85" />
          ))}
          <path d="M44 99 Q60 92 76 99" stroke="#5F3B2E" strokeWidth="2.4" fill="none" strokeLinecap="round" />
        </svg>
        <span className="absolute bottom-5 left-5 rounded-full bg-ink/70 backdrop-blur px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-cream/90">Before</span>
      </div>
      {/* Handle */}
      <div className="absolute inset-y-0" style={{ left: `${pos}%` }}>
        <div className="absolute inset-y-0 -left-px w-0.5 bg-white shadow-[0_0_12px_rgba(0,0,0,0.35)]" />
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-12 w-12 rounded-full bg-white shadow-card flex items-center justify-center">
          <ArrowLeft size={13} className="text-pine -mr-1" /><ArrowRight size={13} className="text-pine -ml-1" />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const [slide, setSlide] = useState(0);
  const [openFaq, setOpenFaq] = useState(0);
  const [reviewIdx, setReviewIdx] = useState(0);
  const featured = SERVICES.filter(s => s.popular);
  const openNow = isOpenNow();

  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % HERO_SLIDES.length), 5000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    const t = setInterval(() => setReviewIdx(r => (r + 1) % REVIEWS.length), 5200);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden bg-pine grain">
        <div aria-hidden className="absolute -top-40 -left-40 h-[32rem] w-[32rem] rounded-full bg-pine-800/80 blur-3xl" />
        <div aria-hidden className="absolute top-1/3 -right-40 h-[30rem] w-[30rem] rounded-full bg-terra/15 blur-3xl" />
        {/* rotated Hindi ribbon */}
        <p aria-hidden className="hidden xl:block absolute right-0 top-1/2 -translate-y-1/2 translate-x-[38%] rotate-90 origin-center text-[10px] font-bold uppercase tracking-[0.5em] text-gold/25 whitespace-nowrap">लेजी हेयर एंड स्किन क्लिनिक · WAKAD</p>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-10 sm:pt-10 sm:pb-14 grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Copy */}
          <div className="lg:col-span-6 text-cream">
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-cream/10 border border-cream/15 backdrop-blur px-3.5 py-1.5 text-[11px] font-bold">
                  <Stars rating={5} size={11} /> <span className="text-cream">5.0 · 8 Google Reviews</span>
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1.5 text-[10.5px] font-bold uppercase tracking-[0.14em] text-gold">
                  <span className={`h-1.5 w-1.5 rounded-full ${openNow ? 'bg-emerald-400' : 'bg-red-400'}`} /> {openNow ? 'Open now · till 7 PM' : 'Closed · opens 10:30 AM'}
                </span>
              </div>

              <h1 className="mt-5 font-display font-semibold tracking-tight leading-[1.02] text-[clamp(2.5rem,7.4vw,4.1rem)]">
                Lazy about glow-ups.<br />
                <span className="italic font-light text-gold">Never</span> lazy<br className="hidden sm:block" /> about <span className="relative inline-block">science.<svg aria-hidden viewBox="0 0 220 24" className="absolute -bottom-2 left-0 w-full" fill="none"><path d="M4 18C70 8 150 6 216 14" stroke="#C4552D" strokeWidth="5" strokeLinecap="round" opacity="0.9"/></svg></span>
              </h1>

              <p className="mt-5 text-cream/75 text-[15px] sm:text-lg leading-relaxed max-w-md">
                Wakad’s dermatologist-led clinic for <strong className="text-cream">hair regrowth, laser, peels &amp; skin rejuvenation</strong> — at Sanskriti Arcade, opposite PCMC School.
              </p>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <button onClick={() => navigate('/book')}
                  className="group inline-flex items-center gap-2 rounded-full bg-terra px-6 sm:px-7 py-3.5 text-sm sm:text-[15px] font-bold text-cream shadow-[0_16px_40px_-12px_rgba(196,85,45,0.6)] hover:bg-terra-dark transition-all">
                  <CalendarCheck size={18} /> Book Free Consultation
                  <ArrowRight size={17} className="transition-transform group-hover:translate-x-1.5" />
                </button>
                <a href={CLINIC.phoneHref} className="inline-flex items-center gap-2 rounded-full border border-cream/25 px-6 py-3.5 text-sm sm:text-[15px] font-bold text-cream hover:bg-cream hover:text-pine transition-all">
                  <Phone size={17} /> 092841 31821
                </a>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11.5px] text-cream/60 font-medium">
                {['MD Dermatologist', 'FDA-approved lasers', 'Fee adjusted on treatment'].map(t => (
                  <span key={t} className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-gold" />{t}</span>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Arched photo composition */}
          <div className="lg:col-span-6 relative h-[420px] sm:h-[520px] lg:h-[560px]">
            {/* big arch image */}
            <div className="absolute left-1/2 -translate-x-1/2 lg:translate-x-0 lg:left-auto lg:right-6 top-0 h-[84%] aspect-[3.1/4] arch overflow-hidden border-[6px] border-cream/90 shadow-soft">
              <AnimatePresence mode="sync">
                <motion.img
                  key={slide} src={HERO_SLIDES[slide].src} alt={HERO_SLIDES[slide].label}
                  initial={{ opacity: 0, scale: 1.08 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                  transition={{ duration: 1.1 }}
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </AnimatePresence>
              <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-pine/80 to-transparent" />
              <p className="absolute bottom-4 inset-x-0 text-center text-[10px] font-bold uppercase tracking-[0.22em] text-gold/90">{HERO_SLIDES[slide].label}</p>
              {/* slide dots */}
              <div className="absolute top-4 right-4 flex flex-col gap-1.5">
                {HERO_SLIDES.map((_, i) => (
                  <button key={i} onClick={() => setSlide(i)} aria-label={`Slide ${i + 1}`}
                    className={`rounded-full transition-all ${i === slide ? 'h-5 w-1.5 bg-gold' : 'h-1.5 w-1.5 bg-white/70'}`} />
                ))}
              </div>
            </div>

            {/* small arch doctor card */}
            <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.35, duration: 0.7 }}
              className="absolute left-0 sm:left-2 bottom-2 sm:bottom-6 w-36 sm:w-44">
              <div className="arch-sm overflow-hidden border-4 border-cream shadow-soft aspect-[3/4]">
                <img src="/images/doctor.jpg" alt="Dr. Sneha, Dermatologist" className="h-full w-full object-cover object-[50%_18%]" />
              </div>
              <div className="mt-2 rounded-2xl bg-cream px-3 py-2 shadow-card text-center">
                <p className="text-[12px] font-extrabold text-pine leading-tight">Dr. Sneha</p>
                <p className="text-[9px] font-semibold uppercase tracking-wider text-terra">MBBS, MD — Dermatologist</p>
              </div>
            </motion.div>

            {/* floating rating pill */}
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.7 }}
              className="animate-floaty absolute right-1 sm:right-0 top-6 sm:top-10 rounded-2xl bg-cream/95 backdrop-blur px-4 py-3 shadow-card border border-gold/40">
              <div className="flex items-center gap-2">
                <div className="h-9 w-9 rounded-full bg-gold-soft flex items-center justify-center"><Star size={18} className="fill-gold text-terra" /></div>
                <div>
                  <p className="font-display font-bold text-pine leading-none">5.0 <span className="text-[11px] font-sans font-bold text-ink/50">/ 5</span></p>
                  <p className="text-[9.5px] font-semibold text-ink/55 mt-0.5">8 Google reviews · 100% ★★★★★</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* ===== Marquee ===== */}
        <div className="relative border-t border-cream/10 bg-pine-800/60 py-2.5 overflow-hidden">
          <div className="animate-marquee whitespace-nowrap flex gap-0 w-max">
            {[...MARQUEE, ...MARQUEE].map((item, i) => (
              <span key={i} className="mx-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.22em] text-cream/55 flex items-center gap-6">
                {item} <Sparkles size={12} className="text-gold" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ============ STATS ============ */}
      <section className="relative z-10 -mt-px bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map(s => <AnimatedStat key={s.label} {...s} />)}
        </div>
      </section>

      {/* ============ TREATMENTS ============ */}
      <section className="bg-cream pb-16 sm:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
            <SectionHeading align="left" eyebrow="What we treat" title={<>Signature <span className="italic text-terra">treatments</span> loved by Wakad</>} />
            <Link to="/services" className="shrink-0 inline-flex items-center gap-2 rounded-full border border-pine/25 text-pine px-5 py-2.5 text-sm font-bold hover:bg-pine hover:text-cream transition-all">
              All 9 treatments & prices <ArrowRight size={15} />
            </Link>
          </div>

          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {featured.map((s, i) => (
              <motion.button
                key={s.id} whileHover={{ y: -6 }} transition={{ type: 'spring', stiffness: 320, damping: 22 }}
                onClick={() => navigate(`/book?service=${s.id}`)}
                className="group relative text-left rounded-3xl border border-pine/10 bg-sand p-5 flex flex-col overflow-hidden hover:shadow-card transition-shadow"
              >
                <span aria-hidden className="absolute -right-3 -top-5 font-display font-black text-7xl text-pine/[0.06] select-none">0{i + 1}</span>
                <div className="h-12 w-12 rounded-2xl bg-pine flex items-center justify-center text-gold"><s.icon size={22} strokeWidth={1.8} /></div>
                <h3 className="mt-4 font-display font-semibold text-lg text-pine leading-snug">{s.name}</h3>
                <p className="mt-1 text-[12.5px] text-ink/65 leading-snug flex-1">{s.tagline}</p>
                <div className="mt-4 flex items-center justify-between w-full">
                  <p className="text-pine font-extrabold">{s.priceNote ? <span className="text-[10px] uppercase font-bold text-ink/50 mr-1">{s.priceNote}</span> : null}₹{s.price.toLocaleString('en-IN')}<span className="text-[10px] font-semibold text-ink/50"> /session</span></p>
                  <span className="h-8 w-8 rounded-full border border-pine/20 flex items-center justify-center text-pine group-hover:bg-terra group-hover:border-terra group-hover:text-cream transition-all"><ArrowRight size={15} /></span>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ============ BEFORE / AFTER + WHY US ============ */}
      <section className="bg-sand/60 border-y border-pine/10 py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="max-w-md mx-auto w-full lg:mx-0">
            <BeforeAfter />
            <p className="mt-3 text-center text-[11.5px] text-ink/55">Drag the slider · Representative acne-correction result, 8-week protocol at Lazy Hair &amp; Skin</p>
          </div>
          <div>
            <SectionHeading align="left" eyebrow="Why patients choose us" title={<>Medical dermatology,<br /><span className="italic text-terra">minus the hospital vibe</span></>} />
            <div className="mt-7 grid sm:grid-cols-2 gap-4">
              {WHY.map(w => (
                <div key={w.title} className="rounded-2xl bg-cream border border-pine/10 p-4 sm:p-5">
                  <w.icon size={22} className="text-terra" strokeWidth={1.8} />
                  <p className="mt-2.5 font-bold text-[13.5px] text-pine">{w.title}</p>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink/65">{w.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ REVIEWS PREVIEW ============ */}
      <section className="relative overflow-hidden bg-pine grain py-16 sm:py-20">
        <div aria-hidden className="absolute -left-24 top-0 h-96 w-96 rounded-full bg-gold/10 blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-4">
            <SectionHeading dark align="left" eyebrow="Google Reviews" title={<><span className="text-gold">5.0</span> stars.<br />Zero faked ones.</>}
              sub="Every review below is a real patient visit — pulled from our public Google profile." />
            <div className="mt-6 flex items-center gap-4">
              <div className="text-center rounded-2xl bg-cream/5 border border-cream/10 px-5 py-4">
                <p className="font-display font-bold text-4xl text-cream">5.0</p>
                <Stars rating={5} size={13} />
                <p className="mt-1 text-[10px] uppercase tracking-widest text-cream/55">8 reviews</p>
              </div>
              <div className="space-y-1.5 flex-1">
                {[5,4,3,2,1].map(n => (
                  <div key={n} className="flex items-center gap-2 text-[11px] text-cream/60">
                    <span className="w-2">{n}</span><Star size={10} className="fill-gold text-gold" />
                    <div className="h-1.5 flex-1 rounded-full bg-cream/10 overflow-hidden"><div className="h-full bg-gold rounded-full" style={{ width: n === 5 ? '100%' : '0%' }} /></div>
                  </div>
                ))}
              </div>
            </div>
            <Link to="/reviews" className="mt-6 inline-flex items-center gap-2 rounded-full bg-gold text-pine px-5 py-2.5 text-sm font-extrabold hover:bg-gold-soft transition-colors">Read all reviews <ArrowRight size={15} /></Link>
          </div>

          <div className="lg:col-span-8 relative h-[300px] sm:h-[280px]">
            <AnimatePresence mode="wait">
              {(() => {
                const r = REVIEWS[reviewIdx];
                return (
                  <motion.figure key={r.id} initial={{ opacity: 0, x: 70 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -70 }} transition={{ duration: 0.45 }}
                    className="absolute inset-0 rounded-3xl bg-cream p-6 sm:p-8 shadow-soft flex flex-col">
                    <div className="flex items-center justify-between gap-3">
                      <Stars rating={r.rating} size={16} />
                      <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-moss bg-sand rounded-full px-3 py-1"><BadgeCheck size={11} /> Google verified</span>
                    </div>
                    <blockquote className="mt-4 text-ink/85 text-[14px] sm:text-[15px] leading-relaxed flex-1 overflow-auto">“{r.text}”</blockquote>
                    <figcaption className="mt-4 flex items-center gap-3 border-t border-pine/10 pt-4">
                      <span className="h-11 w-11 rounded-full flex items-center justify-center text-cream text-sm font-extrabold" style={{ background: r.color }}>{r.initials}</span>
                      <span>
                        <span className="block text-sm font-bold text-pine">{r.name}</span>
                        <span className="block text-[10.5px] text-ink/55 font-medium">{r.service} · {new Date(r.date).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}</span>
                      </span>
                    </figcaption>
                  </motion.figure>
                );
              })()}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ============ VISIT / MAP ============ */}
      <section className="bg-cream py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="Find the clinic" title={<>Right opposite <span className="italic text-terra">PCMC School</span></>} sub="Sanskriti Arcade, 2nd floor · 2 minutes from Wakad Chowk · parking at the arcade" />
          <div className="mt-8 grid lg:grid-cols-5 rounded-3xl overflow-hidden border border-pine/15 shadow-card">
            <iframe title="Lazy Hair and Skin Clinic on Google Maps" src={CLINIC.embedSrc} className="lg:col-span-3 w-full h-64 sm:h-80 lg:h-[26rem] border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            <div className="lg:col-span-2 bg-pine text-cream p-6 sm:p-7 flex flex-col">
              <p className="text-[10.5px] font-bold uppercase tracking-[0.2em] text-gold">Visit us</p>
              <p className="mt-3 flex items-start gap-2.5 text-[13.5px] leading-relaxed text-cream/85"><MapPin size={17} className="mt-0.5 shrink-0 text-terra" />Sanskriti Arcade, 205, Chatrapati Chowk Rd, opp. PCMC School, Kaspate Wasti, Wakad, Pimpri-Chinchwad 411057</p>
              <p className="mt-3 flex items-center gap-2.5 text-[13.5px] text-cream/85"><Clock size={17} className="shrink-0 text-terra" />Open daily · 10:30 AM – 7:00 PM</p>
              <div className="mt-4 flex items-center gap-2.5 text-[13.5px]"><Phone size={17} className="shrink-0 text-terra" /><a href={CLINIC.phoneHref} className="font-extrabold text-cream hover:text-gold">092841 31821</a></div>
              <p className="mt-3 text-[11px] text-cream/50">Plus Code: {CLINIC.plusCode}</p>
              <div className="mt-auto pt-6 grid grid-cols-2 gap-2">
                <a href={CLINIC.mapsLink} target="_blank" rel="noreferrer" className="rounded-xl bg-cream text-pine text-center text-[12.5px] font-extrabold py-3 hover:bg-gold-soft transition-colors">Get Directions</a>
                <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer" className="rounded-xl bg-[#25D366] text-pine text-center text-[12.5px] font-extrabold py-3 hover:brightness-110 transition flex items-center justify-center gap-1.5"><MessageCircle size={14} /> WhatsApp</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ FAQ + FINAL CTA ============ */}
      <section className="bg-sand/60 border-t border-pine/10 py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-7">
            <SectionHeading align="left" eyebrow="Good to know" title={<>Questions, <span className="italic text-terra">answered</span></>} />
            <div className="mt-6 divide-y divide-pine/10 rounded-3xl border border-pine/12 bg-cream overflow-hidden">
              {FAQS.map((f, i) => (
                <div key={i}>
                  <button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} className="w-full flex items-center justify-between gap-4 px-5 sm:px-6 py-4 sm:py-5 text-left">
                    <span className="font-bold text-[13.5px] sm:text-[14.5px] text-pine">{f.q}</span>
                    <ChevronDown size={18} className={`shrink-0 text-terra transition-transform duration-300 ${openFaq === i ? 'rotate-180' : ''}`} />
                  </button>
                  <AnimatePresence initial={false}>
                    {openFaq === i && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.28 }} className="overflow-hidden">
                        <p className="px-5 sm:px-6 pb-5 text-[13px] leading-relaxed text-ink/70">{f.a}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative h-full min-h-[380px] rounded-3xl overflow-hidden shadow-soft">
              <img src="/images/treatment-room.jpg" alt="Treatment room at Lazy Hair and Skin Clinic" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-pine via-pine/60 to-pine/10" />
              <div className="absolute inset-0 p-6 sm:p-8 flex flex-col justify-end">
                <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-gold">Ready when you are</p>
                <h3 className="mt-2 font-display font-semibold text-cream text-2xl sm:text-3xl leading-tight">Your skin deserves<br />a doctor who listens.</h3>
                <button onClick={() => navigate('/book')} className="mt-5 inline-flex w-fit items-center gap-2 rounded-full bg-terra px-6 py-3.5 font-bold text-cream hover:bg-terra-dark transition-colors"><CalendarCheck size={18} /> Book your visit now</button>
                <p className="mt-3 text-[11px] text-cream/65">Or call <a href={CLINIC.phoneHref} className="underline underline-offset-2 hover:text-gold">092841 31821</a> · Free consultation for first-visit procedures</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
