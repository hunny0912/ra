import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  CalendarDays, Clock3, X, RotateCcw, Phone, CalendarCheck, User,
  ChevronDown, CheckCircle2, Ban, History, IndianRupee,
} from 'lucide-react';
import { useBookings, nextDays, generateSlots, slotAvailability, fmtDate, CLINIC } from '../lib/store';
import { useToast } from '../lib/Toast';
import { PageHero } from '../components/ui';

export default function MyAppointments() {
  const { bookings, cancelBooking, rescheduleBooking } = useBookings();
  const toast = useToast();
  const navigate = useNavigate();
  const [rescheduleId, setRescheduleId] = useState<string | null>(null);
  const [newDate, setNewDate] = useState('');
  const [newSlot, setNewSlot] = useState('');

  const sorted = useMemo(() => [...bookings].sort((a, b) => (a.dateISO + a.slot).localeCompare(b.dateISO + b.slot)), [bookings]);
  const days = useMemo(() => nextDays(14), []);
  const slots = useMemo(() => generateSlots(), []);
  const upcoming = sorted.filter(b => b.status === 'upcoming');
  const past = sorted.filter(b => b.status !== 'upcoming').reverse();

  const upcomingAmount = upcoming.reduce((sum, b) => sum + b.servicePrice, 0);

  const openReschedule = (id: string) => {
    setRescheduleId(id);
    setNewDate(days[0].iso);
    setNewSlot('');
  };

  const doReschedule = () => {
    if (!rescheduleId || !newSlot) return;
    rescheduleBooking(rescheduleId, newDate, newSlot);
    toast({ kind: 'success', title: 'Rescheduled!', desc: `Moved to ${fmtDate(newDate)} at ${newSlot}.` });
    setRescheduleId(null);
  };

  return (
    <div className="bg-cream">
      <PageHero eyebrow="My Appointments" title={<>Your visits,<br /><span className="italic text-gold">in one place</span></>} sub="Everything you’ve booked with Lazy Hair and Skin Clinic — manage, reschedule or cancel in seconds." />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
        {/* summary strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl border border-pine/12 bg-sand p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-moss">Upcoming</p>
            <p className="mt-1 font-display font-bold text-3xl text-pine">{upcoming.length}</p>
          </div>
          <div className="rounded-2xl border border-pine/12 bg-sand p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-moss">Past / cancelled</p>
            <p className="mt-1 font-display font-bold text-3xl text-pine">{past.length}</p>
          </div>
          <div className="col-span-2 sm:col-span-1 rounded-2xl border border-gold/40 bg-gold-soft p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-terra-dark flex items-center gap-1"><IndianRupee size={11} />Payable at clinic</p>
            <p className="mt-1 font-display font-bold text-3xl text-pine">₹{upcomingAmount.toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* upcoming */}
        <h2 className="mt-8 flex items-center gap-2 font-display font-semibold text-xl text-pine"><CalendarDays size={20} className="text-terra" /> Upcoming visits</h2>
        {upcoming.length === 0 && (
          <div className="mt-3 rounded-3xl border border-dashed border-pine/25 bg-sand/50 p-10 text-center">
            <p className="font-display text-2xl text-pine">No upcoming visits yet</p>
            <p className="mt-1.5 text-sm text-ink/60">Book your first appointment — it takes less than a minute.</p>
            <button onClick={() => navigate('/book')} className="mt-4 inline-flex items-center gap-2 rounded-full bg-terra text-cream px-6 py-3 font-bold"><CalendarCheck size={17} /> Book now</button>
          </div>
        )}
        <div className="mt-3 space-y-3">
          {upcoming.map(b => (
            <div key={b.id} className="relative overflow-hidden rounded-3xl border border-pine/12 bg-sand p-5 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="absolute left-0 inset-y-0 w-1.5 bg-terra" aria-hidden />
              <div className="flex items-center gap-4 min-w-0 flex-1 pl-1">
                <div className="h-16 w-16 shrink-0 rounded-2xl bg-pine text-gold flex flex-col items-center justify-center">
                  <span className="text-[9px] font-bold uppercase leading-none">{new Date(b.dateISO + 'T00:00:00').toLocaleDateString('en-IN', { month: 'short' })}</span>
                  <span className="font-display font-bold text-2xl leading-none">{new Date(b.dateISO + 'T00:00:00').getDate()}</span>
                </div>
                <div className="min-w-0">
                  <p className="font-bold text-[15px] text-pine leading-snug">{b.serviceName}</p>
                  <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11.5px] text-ink/60 font-medium">
                    <span className="flex items-center gap-1"><Clock3 size={12} />{b.slot} · {b.duration} min</span>
                    <span className="flex items-center gap-1"><User size={12} />Dr. Sneha</span>
                    <span className="font-mono text-[10.5px] text-ink/45">{b.id}</span>
                  </p>
                  <p className="mt-1 text-[11.5px] font-semibold text-terra-dark">₹{b.servicePrice.toLocaleString('en-IN')} payable at clinic</p>
                </div>
              </div>
              <div className="flex sm:flex-col gap-2 shrink-0">
                <button onClick={() => openReschedule(b.id)} className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-xl border border-pine/25 px-4 py-2.5 text-[12px] font-bold text-pine hover:bg-cream transition-colors"><RotateCcw size={13} /> Reschedule</button>
                <button onClick={() => { cancelBooking(b.id); toast({ kind: 'info', title: 'Appointment cancelled', desc: `${b.serviceName} on ${fmtDate(b.dateISO)}` }); }} className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 rounded-xl border border-red-200 text-red-700 px-4 py-2.5 text-[12px] font-bold hover:bg-red-50 transition-colors"><X size={13} /> Cancel</button>
              </div>
            </div>
          ))}
        </div>

        {/* history */}
        {past.length > 0 && (
          <>
            <h2 className="mt-9 flex items-center gap-2 font-display font-semibold text-xl text-pine"><History size={20} className="text-terra" /> History</h2>
            <div className="mt-3 divide-y divide-pine/10 rounded-3xl border border-pine/12 bg-sand/60 overflow-hidden">
              {past.map(b => (
                <div key={b.id} className="flex items-center justify-between gap-3 px-5 py-3.5">
                  <div className="min-w-0">
                    <p className="font-semibold text-[13px] text-ink/75 truncate">{b.serviceName}</p>
                    <p className="text-[10.5px] text-ink/50 font-medium">{fmtDate(b.dateISO)} · {b.slot}</p>
                  </div>
                  <span className={`shrink-0 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[10px] font-extrabold uppercase tracking-wider ${b.status === 'cancelled' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'}`}>
                    {b.status === 'cancelled' ? <><Ban size={11} />Cancelled</> : <><CheckCircle2 size={11} />Completed</>}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}

        <div className="mt-8 rounded-2xl border border-pine/12 bg-cream p-4 flex flex-col sm:flex-row items-center gap-3 justify-between text-center sm:text-left">
          <p className="text-[12.5px] text-ink/70">Arrived already? <strong className="text-pine">Just walk in — the reception will find your booking by your mobile number.</strong></p>
          <a href={CLINIC.phoneHref} className="inline-flex items-center gap-2 rounded-full border border-pine/25 text-pine px-5 py-2.5 text-[12.5px] font-bold hover:bg-sand transition-colors shrink-0"><Phone size={14} /> 092841 31821</a>
        </div>
      </div>

      {/* Reschedule modal */}
      <AnimatePresence>
        {rescheduleId && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] bg-pine/70 backdrop-blur-sm" onClick={() => setRescheduleId(null)} />
            <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 50 }} role="dialog" aria-modal="true" aria-label="Reschedule appointment"
              className="fixed z-[61] inset-x-3 bottom-3 sm:inset-auto sm:left-1/2 sm:top-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 sm:w-[min(560px,94vw)] bg-cream rounded-3xl shadow-soft p-6 max-h-[88vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-xl text-pine">Reschedule visit</h3>
                <button onClick={() => setRescheduleId(null)} aria-label="Close" className="p-2 rounded-full hover:bg-sand"><X size={20} /></button>
              </div>
              <p className="mt-1 flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.18em] text-moss"><ChevronDown size={12} className="rotate-[-90deg]" />Pick a new date</p>
              <div className="mt-2 flex gap-2 overflow-x-auto pb-2">
                {days.map(d => (
                  <button key={d.iso} onClick={() => { setNewDate(d.iso); setNewSlot(''); }}
                    className={`shrink-0 w-16 rounded-2xl border-2 py-2.5 flex flex-col items-center transition-all ${newDate === d.iso ? 'border-terra bg-terra text-cream' : 'border-pine/12 bg-sand text-pine'}`}>
                    <span className="text-[9px] font-bold uppercase">{d.isToday ? 'Today' : d.weekday}</span>
                    <span className="font-display font-bold text-lg leading-tight">{d.day}</span>
                    <span className="text-[9px] font-semibold">{d.month}</span>
                  </button>
                ))}
              </div>
              <p className="mt-3 flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.18em] text-moss"><ChevronDown size={12} className="rotate-[-90deg]" />Pick a new slot</p>
              <div className="mt-2 grid grid-cols-4 sm:grid-cols-6 gap-2">
                {slots.map(s => {
                  const avail = slotAvailability(newDate || days[0].iso, s);
                  const disabled = avail === 'full';
                  return (
                    <button key={s} disabled={disabled} onClick={() => setNewSlot(s)}
                      className={`rounded-xl h-11 text-[11.5px] font-bold border transition-all ${newSlot === s ? 'bg-pine text-cream border-pine' : disabled ? 'bg-shell/40 text-ink/30 line-through cursor-not-allowed border-transparent' : 'bg-sand border-pine/12 text-pine hover:border-pine/40'}`}>
                      {s}
                    </button>
                  );
                })}
              </div>
              <button onClick={doReschedule} disabled={!newSlot} className="mt-5 w-full rounded-2xl bg-pine disabled:opacity-40 py-4 font-extrabold text-cream hover:bg-pine-800 transition-colors">Move appointment{newSlot ? ` to ${newSlot}` : ''}</button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
