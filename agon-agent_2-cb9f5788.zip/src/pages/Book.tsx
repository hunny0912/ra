import React, { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Check, ChevronLeft, ChevronRight, CalendarDays, Clock3, User, Stethoscope,
  ShieldCheck, PartyPopper, MessageCircle, Phone, BadgePercent, Info, Sparkles,
} from 'lucide-react';
import { SERVICES } from '../data/services';
import { useBookings, generateSlots, slotAvailability, nextDays, CLINIC } from '../lib/store';
import { useToast } from '../lib/Toast';

const STEPS = ['Treatment', 'Date & Time', 'Your Details', 'Confirmed'];
const CONCERNS = ['Hair fall / thinning', 'Acne / pimples', 'Pigmentation / melasma', 'Scars / marks', 'Dark circles / dull skin', 'Unwanted hair', 'Anti-ageing / wrinkles', 'General check-up'];

export default function Book() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { addBooking } = useBookings();
  const toast = useToast();

  const [step, setStep] = useState(0);
  const [serviceId, setServiceId] = useState(params.get('service') ?? '');
  const [dateISO, setDateISO] = useState(() => nextDays(1)[0].iso);
  const [slot, setSlot] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [concern, setConcern] = useState('');
  const [firstVisit, setFirstVisit] = useState(true);
  const [touched, setTouched] = useState(false);
  const [bookingId, setBookingId] = useState('');

  const service = SERVICES.find(s => s.id === serviceId)
    ?? (serviceId === 'consultation' ? { id: 'consultation', name: 'General Consultation', price: 500, duration: 30 } : null);
  const days = useMemo(() => nextDays(14), []);
  const slots = useMemo(() => generateSlots(), []);
  const isServiceStepValid = !!service;
  const isSlotStepValid = !!slot;
  const phoneValid = /^[6-9]\d{9}$/.test(phone.replace(/\D/g, ''));
  const nameValid = name.trim().length >= 2;
  const isDetailsValid = nameValid && phoneValid;

  const confirm = () => {
    if (!service || !slot) return;
    const b = addBooking({
      serviceId: service.id, serviceName: service.name, servicePrice: service.price,
      duration: service.duration, dateISO, slot, name: name.trim(),
      phone: phone.replace(/\D/g, ''), concern: concern || 'General consultation', firstVisit,
    });
    setBookingId(b.id);
    setStep(3);
    toast({ kind: 'success', title: 'Appointment booked!', desc: `${service.name} on ${new Date(dateISO + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} at ${slot}` });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const waConfirm = `https://wa.me/919284131821?text=${encodeURIComponent(`Hi! I just booked an appointment (ID: ${bookingId}) — ${service?.name} on ${dateISO} at ${slot} for ${name}. Please confirm my slot. Thank you!`)}`;

  return (
    <div className="bg-cream min-h-screen">
      {/* Progress header */}
      <div className="bg-pine text-cream">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-gold">Free booking · No advance payment</p>
          <h1 className="mt-1 font-display font-semibold text-2xl sm:text-3xl">Book your visit</h1>
          {/* stepper */}
          <ol className="mt-4 flex items-center gap-1 sm:gap-2">
            {STEPS.map((label, i) => {
              const done = i < step, current = i === step;
              return (
                <li key={label} className="flex items-center gap-1 sm:gap-2 flex-1 min-w-0">
                  <span className={`h-6 w-6 sm:h-7 sm:w-7 shrink-0 rounded-full flex items-center justify-center text-[10px] sm:text-[11px] font-extrabold transition-all ${done ? 'bg-gold text-pine' : current ? 'bg-terra text-cream ring-2 ring-terra/40' : 'bg-cream/15 text-cream/55'}`}>
                    {done ? <Check size={13} strokeWidth={3.5} /> : i + 1}
                  </span>
                  <span className={`hidden xs:block text-[10px] sm:text-[11px] font-bold truncate ${current ? 'text-cream' : done ? 'text-gold' : 'text-cream/45'}`}>{label}</span>
                  {i < STEPS.length - 1 && <span className={`h-px flex-1 ${done ? 'bg-gold' : 'bg-cream/15'}`} />}
                </li>
              );
            })}
          </ol>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <AnimatePresence mode="wait">

          {/* ===== STEP 1: Treatment ===== */}
          {step === 0 && (
            <motion.section key="s0" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }}>
              <h2 className="font-display font-semibold text-xl text-pine">Step 1 — Which treatment?</h2>
              <p className="text-[13px] text-ink/60 mt-1">Not sure? Pick “General Consultation” — Dr. Sneha will prescribe the right plan. Consultation fee ₹500, adjusted against any treatment.</p>
              <div className="mt-4 grid sm:grid-cols-2 gap-3">
                {SERVICES.map(s => {
                  const selected = serviceId === s.id;
                  return (
                    <button key={s.id} onClick={() => setServiceId(s.id)}
                      className={`relative text-left rounded-2xl border-2 p-4 flex items-start gap-3 transition-all ${selected ? 'border-terra bg-terra-soft/60 shadow-card' : 'border-pine/12 bg-sand hover:border-pine/30'}`}>
                      <span className={`h-11 w-11 shrink-0 rounded-xl flex items-center justify-center ${selected ? 'bg-terra text-cream' : 'bg-pine text-gold'}`}><s.icon size={20} /></span>
                      <span className="min-w-0">
                        <span className="block font-bold text-[13px] text-pine leading-snug">{s.name}</span>
                        <span className="block text-[10.5px] text-ink/55 mt-1">{s.duration} min · {s.sessions}</span>
                        <span className="block text-[12px] font-extrabold text-pine mt-0.5">₹{s.price.toLocaleString('en-IN')}<span className="font-semibold text-[10px] text-ink/50"> /session</span></span>
                      </span>
                      {selected && <span className="absolute top-3 right-3 h-6 w-6 rounded-full bg-terra text-cream flex items-center justify-center"><Check size={14} strokeWidth={3.5} /></span>}
                    </button>
                  );
                })}
                <button onClick={() => setServiceId('consultation')}
                  className={`relative text-left rounded-2xl border-2 border-dashed p-4 flex items-start gap-3 transition-all ${serviceId === 'consultation' ? 'border-terra bg-terra-soft/60' : 'border-pine/25 bg-cream hover:border-pine/40'}`}>
                  <span className="h-11 w-11 shrink-0 rounded-xl bg-gold-soft text-terra-dark flex items-center justify-center"><Stethoscope size={20} /></span>
                  <span>
                    <span className="block font-bold text-[13px] text-pine leading-snug">General Consultation</span>
                    <span className="block text-[10.5px] text-ink/55 mt-1">30 min · diagnosis & treatment plan</span>
                    <span className="block text-[12px] font-extrabold text-pine mt-0.5">₹500 <span className="font-semibold text-[10px] text-emerald-700">adjusted on treatment</span></span>
                  </span>
                  {serviceId === 'consultation' && <span className="absolute top-3 right-3 h-6 w-6 rounded-full bg-terra text-cream flex items-center justify-center"><Check size={14} strokeWidth={3.5} /></span>}
                </button>
              </div>
            </motion.section>
          )}

          {/* ===== STEP 2: Date & time ===== */}
          {step === 1 && (
            <motion.section key="s1" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }}>
              <h2 className="font-display font-semibold text-xl text-pine">Step 2 — Pick a date & time</h2>
              <p className="text-[13px] text-ink/60 mt-1">Clinic hours: every day, 10:30 AM – 7:00 PM. Greyed-out slots are fully booked.</p>

              {/* date strip */}
              <p className="mt-5 flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.18em] text-moss"><CalendarDays size={13} /> Next 14 days</p>
              <div className="mt-2 flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 sm:mx-0 sm:px-0">
                {days.map(d => {
                  const selected = dateISO === d.iso;
                  return (
                    <button key={d.iso} onClick={() => { setDateISO(d.iso); setSlot(''); }}
                      className={`shrink-0 w-[68px] rounded-2xl border-2 py-3 flex flex-col items-center transition-all ${selected ? 'border-terra bg-terra text-cream shadow-card' : 'border-pine/12 bg-sand text-pine hover:border-pine/35'}`}>
                      <span className={`text-[9.5px] font-bold uppercase tracking-widest ${selected ? 'text-cream/85' : 'text-moss'}`}>{d.isToday ? 'Today' : d.weekday}</span>
                      <span className="font-display font-bold text-xl leading-tight">{d.day}</span>
                      <span className={`text-[9.5px] font-semibold ${selected ? 'text-cream/85' : 'text-ink/55'}`}>{d.month}</span>
                    </button>
                  );
                })}
              </div>

              {/* slots */}
              <p className="mt-4 flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.18em] text-moss"><Clock3 size={13} /> Available slots — {new Date(dateISO + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
              <div className="mt-2 grid grid-cols-4 sm:grid-cols-6 gap-2">
                {slots.map(s => {
                  const avail = slotAvailability(dateISO, s);
                  const selected = slot === s;
                  const disabled = avail === 'full';
                  return (
                    <button key={s} disabled={disabled} onClick={() => setSlot(s)}
                      className={`relative rounded-xl h-11 text-[11.5px] font-bold border transition-all ${
                        selected ? 'bg-pine text-cream border-pine ring-2 ring-gold/60' :
                        disabled ? 'bg-shell/40 text-ink/30 border-transparent cursor-not-allowed line-through' :
                        avail === 'few' ? 'bg-gold-soft border-gold/50 text-terra-dark hover:border-terra' :
                        'bg-sand border-pine/12 text-pine hover:border-pine/40'
                      }`}>
                      {s}
                      {avail === 'few' && !selected && <span className="absolute bottom-0.5 inset-x-0 text-[8px] font-extrabold text-terra">2 left</span>}
                    </button>
                  );
                })}
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[10.5px] text-ink/55">
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-gold-soft border border-gold/50" /> Almost full</span>
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-shell/60" /> Fully booked</span>
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-pine" /> Selected</span>
              </div>
            </motion.section>
          )}

          {/* ===== STEP 3: Details ===== */}
          {step === 2 && (
            <motion.section key="s2" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }}>
              <h2 className="font-display font-semibold text-xl text-pine">Step 3 — Almost done!</h2>
              <p className="text-[13px] text-ink/60 mt-1">We’ll SMS your appointment confirmation. No payment needed now.</p>
              <div className="mt-5 grid sm:grid-cols-5 gap-5">
                <div className="sm:col-span-3 space-y-4">
                  <div>
                    <label htmlFor="bk-name" className="text-[11px] font-bold text-ink/70">Your name *</label>
                    <input id="bk-name" value={name} onChange={e => setName(e.target.value)} onBlur={() => setTouched(true)}
                      placeholder="e.g. Priya Deshmukh" autoComplete="name"
                      className={`mt-1.5 w-full h-12 rounded-xl border-2 bg-sand px-4 text-[14px] font-medium outline-none transition-colors ${touched && !nameValid ? 'border-red-400' : 'border-transparent focus:border-terra'}`} />
                    {touched && !nameValid && <p className="mt-1 text-[11px] text-red-600 font-semibold">Please enter at least 2 characters.</p>}
                  </div>
                  <div>
                    <label htmlFor="bk-phone" className="text-[11px] font-bold text-ink/70">Mobile number * <span className="font-semibold text-ink/45">(we call to confirm)</span></label>
                    <div className="mt-1.5 flex rounded-xl border-2 overflow-hidden focus-within:border-terra border-transparent bg-sand">
                      <span className="flex items-center px-3.5 text-[13px] font-bold text-pine bg-shell/60 border-r border-pine/10">+91</span>
                      <input id="bk-phone" value={phone} inputMode="numeric" autoComplete="tel-national"
                        onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} onBlur={() => setTouched(true)}
                        placeholder="98765 43210" className="w-full h-12 px-3.5 bg-transparent outline-none text-[14px] font-medium" />
                    </div>
                    {touched && !phoneValid && <p className="mt-1 text-[11px] text-red-600 font-semibold">Enter a valid 10-digit Indian mobile number.</p>}
                  </div>
                  <div>
                    <label htmlFor="bk-concern" className="text-[11px] font-bold text-ink/70">Main concern</label>
                    <select id="bk-concern" value={concern} onChange={e => setConcern(e.target.value)}
                      className="mt-1.5 w-full h-12 rounded-xl border-2 border-transparent bg-sand px-4 text-[13.5px] font-medium outline-none focus:border-terra">
                      <option value="">Choose a concern… (optional)</option>
                      {CONCERNS.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <label className="flex items-center gap-3 rounded-2xl border border-pine/12 bg-sand p-4 cursor-pointer select-none">
                    <input type="checkbox" checked={firstVisit} onChange={e => setFirstVisit(e.target.checked)} className="h-5 w-5 accent-[#C4552D]" />
                    <span className="text-[12.5px] font-semibold text-pine">This is my first visit to the clinic<span className="block text-[10.5px] font-medium text-ink/55">First-time patients get a complimentary skin analysis scan.</span></span>
                  </label>
                </div>

                {/* Summary card */}
                <aside className="sm:col-span-2">
                  <div className="rounded-2xl border border-pine/12 bg-pine text-cream p-5 sticky top-24">
                    <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gold">Visit summary</p>
                    <p className="mt-2.5 font-display font-semibold leading-snug">{service?.name ?? 'General Consultation'}</p>
                    <div className="mt-3 space-y-1.5 text-[12px] text-cream/80">
                      <p className="flex items-center gap-2"><CalendarDays size={13} className="text-gold" />{new Date(dateISO + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'long' })}</p>
                      <p className="flex items-center gap-2"><Clock3 size={13} className="text-gold" />{slot} · {service?.duration ?? 30} min</p>
                      <p className="flex items-center gap-2"><User size={13} className="text-gold" />Dr. Sneha · MBBS, MD</p>
                    </div>
                    <div className="mt-4 border-t border-cream/15 pt-3 flex items-center justify-between">
                      <span className="text-[12px] text-cream/70">Payable at clinic</span>
                      <span className="font-display font-bold text-xl text-gold">₹{(service?.price ?? 500).toLocaleString('en-IN')}</span>
                    </div>
                    <p className="mt-2 flex items-start gap-1.5 text-[10px] text-cream/55"><ShieldCheck size={12} className="mt-0.5 shrink-0" />Consultation fee adjusted against any treatment taken in the same visit.</p>
                  </div>
                </aside>
              </div>
            </motion.section>
          )}

          {/* ===== STEP 4: Confirmed ===== */}
          {step === 3 && (
            <motion.section key="s3" initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', damping: 22, stiffness: 240 }} className="text-center py-4">
              <div className="relative mx-auto h-24 w-24">
                <span className="absolute inset-0 rounded-full bg-gold/30 animate-ping-dot" />
                <span className="relative h-24 w-24 rounded-full bg-pine flex items-center justify-center shadow-soft"><PartyPopper size={44} className="text-gold" /></span>
              </div>
              <h2 className="mt-6 font-display font-semibold text-3xl text-pine">Appointment <span className="italic text-terra">confirmed!</span></h2>
              <p className="mt-2 text-[14px] text-ink/70">See you at the clinic, <strong>{name.split(' ')[0] || 'friend'}</strong>. We’ve noted your slot:</p>
              <div className="mt-5 inline-block rounded-3xl border-2 border-dashed border-pine/25 bg-sand px-8 py-5">
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-moss">Booking ID</p>
                <p className="font-mono font-extrabold text-lg text-pine tracking-wider">{bookingId}</p>
                <p className="mt-2 font-bold text-pine">{service?.name}</p>
                <p className="text-[13px] text-ink/65">{new Date(dateISO + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })} · {slot}</p>
              </div>

              <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3 max-w-lg mx-auto">
                <a href={waConfirm} target="_blank" rel="noreferrer" className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] text-pine px-6 py-3.5 font-extrabold hover:brightness-105 transition"><MessageCircle size={18} /> Confirm on WhatsApp</a>
                <button onClick={() => navigate('/my-appointments')} className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-pine text-cream px-6 py-3.5 font-bold hover:bg-pine-800 transition-colors"><CalendarDays size={18} /> View my appointments</button>
              </div>

              <div className="mt-8 mx-auto max-w-md text-left rounded-2xl bg-gold-soft/60 border border-gold/40 p-4">
                <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-widest text-terra-dark"><BadgePercent size={13} /> Preparation tips</p>
                <ul className="mt-2 text-[12px] text-ink/75 space-y-1.5">
                  <li className="flex gap-1.5"><Sparkles size={12} className="mt-0.5 shrink-0 text-terra" />Avoid waxing/threading 2 weeks before laser sessions</li>
                  <li className="flex gap-1.5"><Sparkles size={12} className="mt-0.5 shrink-0 text-terra" />Come with a clean, makeup-free face for facials & peels</li>
                  <li className="flex gap-1.5"><Sparkles size={12} className="mt-0.5 shrink-0 text-terra" />Carry any previous prescriptions or reports</li>
                </ul>
              </div>
              <p className="mt-6 text-[11px] text-ink/50 flex items-center justify-center gap-2"><Info size={12} /> Need to reschedule? Call <a href={CLINIC.phoneHref} className="font-bold text-terra">092841 31821</a> or use My Appointments.</p>
            </motion.section>
          )}
        </AnimatePresence>

        {/* nav buttons */}
        {step < 3 && (
          <div className="mt-8 flex items-center justify-between gap-3">
            {step > 0
              ? <button onClick={() => setStep(s => s - 1)} className="inline-flex items-center gap-1.5 rounded-full border border-pine/25 text-pine px-5 py-3 text-sm font-bold hover:bg-sand transition-colors"><ChevronLeft size={17} /> Back</button>
              : <span />}
            {step === 0 && (
              <button onClick={() => setStep(1)} disabled={!isServiceStepValid}
                className="inline-flex items-center gap-1.5 rounded-full bg-pine disabled:opacity-40 disabled:cursor-not-allowed text-cream px-6 py-3 text-sm font-extrabold hover:bg-pine-800 transition-colors">Choose date & time <ChevronRight size={17} /></button>
            )}
            {step === 1 && (
              <button onClick={() => setStep(2)} disabled={!isSlotStepValid}
                className="inline-flex items-center gap-1.5 rounded-full bg-pine disabled:opacity-40 disabled:cursor-not-allowed text-cream px-6 py-3 text-sm font-extrabold hover:bg-pine-800 transition-colors">My details <ChevronRight size={17} /></button>
            )}
            {step === 2 && (
              <button onClick={confirm} disabled={!isDetailsValid}
                className="inline-flex items-center gap-2 rounded-full bg-terra disabled:opacity-40 disabled:cursor-not-allowed text-cream px-7 py-3.5 text-sm font-extrabold hover:bg-terra-dark transition-colors shadow-card"><Check size={17} strokeWidth={3} /> Confirm Appointment</button>
            )}
          </div>
        )}

        {/* reassurance strip */}
        {step < 3 && (
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-1.5 text-[10.5px] font-semibold text-ink/55">
            <span className="flex items-center gap-1.5"><ShieldCheck size={12} className="text-emerald-700" />Free cancellation up to 2 hrs before</span>
            <span className="flex items-center gap-1.5"><Phone size={12} className="text-emerald-700" />Confirmation call within 30 minutes</span>
            <span className="flex items-center gap-1.5"><User size={12} className="text-emerald-700" />Seen by Dr. Sneha personally</span>
          </div>
        )}
      </div>
    </div>
  );
}
