import React, { useState } from 'react';
import {
  Phone, MessageCircle, MapPin, Clock, Navigation, Send, CheckCircle2,
  ChevronDown, Mail, Building2, ExternalLink,
} from 'lucide-react';
import { CLINIC } from '../lib/store';
import { useToast } from '../lib/Toast';
import { PageHero } from '../components/ui';

const SUBJECTS = ['Booking enquiry', 'Treatment question', 'Follow-up about my procedure', 'Feedback', 'Something else'];

const HOURS: [string, string][] = [
  ['Monday', '10:30 AM – 7:00 PM'], ['Tuesday', '10:30 AM – 7:00 PM'], ['Wednesday', '10:30 AM – 7:00 PM'],
  ['Thursday', '10:30 AM – 7:00 PM'], ['Friday', '10:30 AM – 7:00 PM'], ['Saturday', '10:30 AM – 7:00 PM'], ['Sunday', '10:30 AM – 7:00 PM'],
];
const todayIdx = new Date().getDay(); // Sunday = 0
const ordered = HOURS.map((h, i) => ({ day: h[0], time: h[1], today: (i === 6 ? 0 : i + 1) === todayIdx }));

export default function Contact() {
  const toast = useToast();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [touched, setTouched] = useState(false);

  const phoneValid = /^[6-9]\d{9}$/.test(phone.replace(/\D/g, ''));
  const valid = name.trim().length >= 2 && phoneValid && message.trim().length >= 6;

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (!valid) return;
    setSent(true);
    toast({ kind: 'success', title: 'Message received!', desc: 'The clinic team will call you back within clinic hours.' });
  };

  return (
    <div className="bg-cream">
      <PageHero eyebrow="Contact & Directions" title={<>Two minutes from<br /><span className="italic text-gold">Wakad Chowk</span></>} sub="Sanskriti Arcade, 2nd floor — right opposite PCMC School. Open every day, no lunch break." />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid lg:grid-cols-12 gap-8">
        {/* ===== Form ===== */}
        <form onSubmit={send} className="lg:col-span-5 rounded-3xl border border-pine/12 bg-sand p-6 sm:p-7 h-fit">
          <h2 className="font-display font-semibold text-2xl text-pine">Send a message</h2>
          <p className="mt-1 text-[13px] text-ink/60">Prefer typing? Leave a note and we’ll call you back the same day.</p>

          {sent ? (
            <div className="mt-6 rounded-2xl bg-emerald-50 border border-emerald-200 p-6 text-center">
              <CheckCircle2 size={40} className="mx-auto text-emerald-600" />
              <p className="mt-3 font-bold text-emerald-900">Message received, {name.split(' ')[0]}!</p>
              <p className="mt-1 text-[13px] text-emerald-800">We’ll call <strong>+91 {phone}</strong> within clinic hours (10:30 AM – 7:00 PM). For urgent queries, call <a className="underline font-bold" href={CLINIC.phoneHref}>092841 31821</a>.</p>
              <button type="button" onClick={() => { setSent(false); setName(''); setPhone(''); setMessage(''); setTouched(false); }} className="mt-4 text-[12px] font-bold text-emerald-800 underline underline-offset-2">Send another message</button>
            </div>
          ) : (
            <>
              <div className="mt-5 grid sm:grid-cols-2 gap-3">
                <label className="block text-[11px] font-bold text-ink/70">Name *
                  <input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" className={`mt-1.5 w-full h-11 rounded-xl bg-cream px-4 outline-none border-2 text-[13.5px] ${touched && name.trim().length < 2 ? 'border-red-400' : 'border-transparent focus:border-terra'}`} />
                </label>
                <label className="block text-[11px] font-bold text-ink/70">Mobile *
                  <div className={`mt-1.5 flex rounded-xl border-2 overflow-hidden bg-cream ${touched && !phoneValid ? 'border-red-400' : 'border-transparent focus-within:border-terra'}`}>
                    <span className="flex items-center px-3 text-[12px] font-bold text-pine bg-shell/60">+91</span>
                    <input value={phone} inputMode="numeric" onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} placeholder="98765 43210" className="w-full h-11 px-3 bg-transparent outline-none text-[13.5px]" />
                  </div>
                </label>
              </div>
              <label className="block mt-3 text-[11px] font-bold text-ink/70">Subject
                <span className="relative mt-1.5 block">
                  <select value={subject} onChange={e => setSubject(e.target.value)} className="w-full appearance-none h-11 rounded-xl bg-cream px-4 pr-9 outline-none border-2 border-transparent focus:border-terra text-[13px] font-medium">
                    {SUBJECTS.map(s => <option key={s}>{s}</option>)}
                  </select>
                  <ChevronDown size={15} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-ink/50" />
                </span>
              </label>
              <label className="block mt-3 text-[11px] font-bold text-ink/70">Message *
                <textarea required value={message} onChange={e => setMessage(e.target.value)} rows={4} placeholder="Tell us about your skin or hair concern, or how we can help…" className={`mt-1.5 w-full rounded-xl bg-cream p-4 outline-none border-2 text-[13px] leading-relaxed ${touched && message.trim().length < 6 ? 'border-red-400' : 'border-transparent focus:border-terra'}`} />
              </label>
              {touched && !valid && <p className="mt-1 text-[11px] text-red-600 font-semibold">Please fill in all fields correctly.</p>}
              <button type="submit" className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-terra py-4 font-extrabold text-cream hover:bg-terra-dark transition-colors"><Send size={17} /> Send message</button>
            </>
          )}

          <div className="mt-5 grid grid-cols-2 gap-2">
            <a href={CLINIC.phoneHref} className="flex items-center justify-center gap-2 rounded-xl border border-pine/25 py-3 text-[12.5px] font-extrabold text-pine hover:bg-cream transition-colors"><Phone size={15} /> Call</a>
            <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] py-3 text-[12.5px] font-extrabold text-pine hover:brightness-105 transition"><MessageCircle size={15} /> WhatsApp</a>
          </div>
        </form>

        {/* ===== Map + hours ===== */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="rounded-3xl overflow-hidden border border-pine/15 shadow-card flex-1 min-h-[280px]">
            <iframe title="Map to Lazy Hair and Skin Clinic" src={CLINIC.embedSrc} className="w-full h-full min-h-[280px] border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="rounded-3xl border border-pine/12 bg-sand p-5">
              <p className="flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.2em] text-terra"><MapPin size={13} /> Address</p>
              <p className="mt-2 text-[13px] leading-relaxed text-ink/85">Sanskriti Arcade, 205, Chatrapati Chowk Rd, opp. PCMC School, Kaspate Wasti, Wakad, Pimpri-Chinchwad, Maharashtra 411057</p>
              <p className="mt-2 flex items-center gap-1.5 text-[10.5px] font-semibold text-ink/55"><Building2 size={11} /> Plus Code: {CLINIC.plusCode}</p>
              <a href={CLINIC.mapsLink} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-pine text-cream px-4 py-2 text-[11.5px] font-bold hover:bg-pine-800 transition-colors"><Navigation size={12} /> Open in Google Maps <ExternalLink size={11} /></a>
            </div>
            <div className="rounded-3xl border border-pine/12 bg-sand p-5">
              <p className="flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.2em] text-terra"><Clock size={13} /> Clinic hours</p>
              <ul className="mt-2 text-[12.5px]">
                {ordered.map(h => (
                  <li key={h.day} className={`flex items-center justify-between py-[3px] ${h.today ? 'font-extrabold text-terra-dark' : 'text-ink/75'}`}>
                    <span>{h.day}{h.today && ' · Today'}</span><span>{h.time}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-2 flex items-center gap-1.5 text-[10.5px] font-semibold text-ink/55"><Mail size={11} /> No lunch break · Walk-ins welcome</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
