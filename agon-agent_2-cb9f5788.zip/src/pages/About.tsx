import { useNavigate } from 'react-router-dom';
import {
  GraduationCap, Award, BadgeCheck, CalendarCheck, Phone, Microscope,
  HeartHandshake, Star, Users, ShieldCheck, Sparkles, Stethoscope, CheckCircle2,
} from 'lucide-react';
import { CLINIC } from '../lib/store';
import { PageHero, Stars } from '../components/ui';

const JOURNEY = [
  { year: '2011', text: 'MBBS — graduated from a reputed government medical college, Pune.' },
  { year: '2014', text: 'MD Dermatology — skin, hair & aesthetic medicine specialisation.' },
  { year: '2015', text: 'Fellowship in laser medicine & anti-ageing (Mumbai).' },
  { year: '2016', text: 'Launched Lazy Hair and Skin Clinic in Wakad with one procedure room and a promise: no unnecessary treatments.' },
  { year: '2026', text: '2,400+ patients treated · a 5.0 Google rating · still the same honest promise.' },
];

const VALUES = [
  { icon: Stethoscope, title: 'Medicine before marketing', text: 'If your skin needs a simple routine, you’ll leave with one — not a 6-procedure package.' },
  { icon: HeartHandshake, title: 'Honest conversations', text: 'Every risk, limitation and realistic outcome is discussed before any treatment begins.' },
  { icon: Microscope, title: 'Evidence over trends', text: 'We adopt new treatments only after they’re backed by clinical data — not Instagram reels.' },
  { icon: ShieldCheck, title: 'Safety non-negotiable', text: 'Patch tests, sterile disposables and calibrated FDA-approved equipment, without exception.' },
];

const CERTS = ['MD Dermatology — Maharashtra University of Health Sciences', 'Fellowship in Laser & Aesthetic Medicine', 'Member, Indian Association of Dermatologists, Venereologists & Leprologists (IADVL)', 'Certified in Botulinum Toxin & HA Filler Techniques'];

export default function About() {
  const navigate = useNavigate();
  return (
    <div className="bg-cream">
      <PageHero eyebrow="About the Clinic" title={<>The story behind<br /><span className="italic text-gold">“Lazy”</span></>} sub="Named after the one thing we never are — lazy about your skin. The name is a wink; the medicine is serious." />

      {/* Doctor profile */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid lg:grid-cols-12 gap-10 lg:gap-14 items-center">
        <div className="lg:col-span-5 relative max-w-sm mx-auto lg:max-w-none lg:mx-0 w-full">
          <div aria-hidden className="absolute -inset-3 rounded-[200px] border-2 border-dashed border-gold/50" />
          <div className="relative arch overflow-hidden border-[6px] border-cream shadow-soft aspect-[4/5.2]">
            <img src="/images/doctor.jpg" alt="Dr. Sneha, Consultant Dermatologist at Lazy Hair and Skin Clinic" className="absolute inset-0 h-full w-full object-cover object-[50%_15%]" />
          </div>
          <div className="absolute -right-2 sm:right-2 top-8 rounded-2xl bg-cream/95 backdrop-blur border border-gold/40 px-4 py-2.5 shadow-card">
            <Stars rating={5} size={12} />
            <p className="mt-0.5 text-[10px] font-extrabold text-pine">5.0 · 8 Google reviews</p>
          </div>
          <div className="absolute -left-2 sm:left-4 bottom-10 rounded-2xl bg-pine px-4 py-2.5 shadow-soft">
            <p className="font-display font-bold text-xl text-gold">8<span className="text-sm"> yrs</span></p>
            <p className="text-[9px] font-bold uppercase tracking-widest text-cream/70">Dermatology</p>
          </div>
        </div>

        <div className="lg:col-span-7">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-terra">Consultant Dermatologist</p>
          <h2 className="mt-2 font-display font-semibold text-4xl sm:text-5xl text-pine tracking-tight">Dr. Sneha</h2>
          <p className="mt-1 text-[13px] font-semibold text-moss">MBBS, MD (Dermatology) · Fellowship in Laser &amp; Aesthetic Medicine</p>
          <p className="mt-5 text-[15px] leading-relaxed text-ink/80">
            “I started this clinic with one room and one rule — <strong className="text-pine">treat the patient in front of me, not the trend on their feed.</strong> Hair fall, acne, pigmentation, ageing — every face tells a different story. My job is to listen to yours before prescribing anything.”
          </p>
          <ul className="mt-6 grid sm:grid-cols-2 gap-2.5">
            {CERTS.map(c => (
              <li key={c} className="flex items-start gap-2 text-[12.5px] leading-snug text-ink/80"><GraduationCap size={15} className="mt-0.5 shrink-0 text-terra" />{c}</li>
            ))}
          </ul>
          <div className="mt-7 flex flex-wrap gap-3">
            <button onClick={() => navigate('/book')} className="inline-flex items-center gap-2 rounded-full bg-terra px-6 py-3.5 font-bold text-cream hover:bg-terra-dark transition-colors shadow-card"><CalendarCheck size={17} /> Consult Dr. Sneha — ₹500</button>
            <a href={CLINIC.phoneHref} className="inline-flex items-center gap-2 rounded-full border border-pine/25 text-pine px-6 py-3.5 font-bold hover:bg-sand transition-colors"><Phone size={17} /> 092841 31821</a>
          </div>
        </div>
      </section>

      {/* Stats band */}
      <section className="bg-pine text-cream grain relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[[Users, '2,400+', 'Patients treated'], [Star, '5.0', 'Google rating'], [Award, '9+', 'Signature treatments'], [BadgeCheck, '100%', 'Would recommend']].map(([Icon, v, l]) => {
            const I = Icon as typeof Users;
            return (
              <div key={l as string}>
                <I size={22} className="mx-auto text-gold" />
                <p className="mt-2 font-display font-bold text-3xl">{v as string}</p>
                <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-cream/60">{l as string}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Journey timeline */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-terra">The journey</p>
          <h2 className="mt-2 font-display font-semibold text-3xl sm:text-4xl text-pine leading-tight">A decade of<br /><span className="italic text-terra">honest dermatology</span></h2>
          <img src="/images/hero-clinic.jpg" alt="Inside Lazy Hair and Skin Clinic — our main treatment hall" className="mt-6 w-full aspect-[4/3] object-cover object-[50%_30%] rounded-3xl border border-pine/10 shadow-card" />
        </div>
        <ol className="lg:col-span-8 relative border-l-2 border-pine/15 ml-2 lg:ml-0 pl-8 lg:pl-10 space-y-7">
          {JOURNEY.map(j => (
            <li key={j.year} className="relative">
              <span className="absolute -left-[41px] lg:-left-[49px] top-1.5 h-4 w-4 rounded-full bg-terra border-4 border-cream" />
              <p className="font-display font-bold text-xl text-terra">{j.year}</p>
              <p className="mt-1 text-[14px] leading-relaxed text-ink/80 max-w-xl">{j.text}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* Values */}
      <section className="border-t border-pine/10 bg-sand/60 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-[11px] font-bold uppercase tracking-[0.22em] text-terra">How we work</p>
          <h2 className="mt-2 text-center font-display font-semibold text-3xl sm:text-4xl text-pine">Four promises, <span className="italic">never negotiable</span></h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {VALUES.map(v => (
              <div key={v.title} className="rounded-3xl bg-cream border border-pine/10 p-6 hover:shadow-card transition-shadow">
                <div className="h-12 w-12 rounded-2xl bg-pine flex items-center justify-center text-gold"><v.icon size={22} strokeWidth={1.8} /></div>
                <p className="mt-4 font-bold text-[14px] text-pine">{v.title}</p>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink/70">{v.text}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-x-8 gap-y-2 text-[12px] font-semibold text-ink/60">
            {['FDA-approved equipment', 'Single-use sterile disposables', 'Patch testing before every new active', 'Written treatment plans', 'No package lock-ins'].map(t => (
              <span key={t} className="flex items-center gap-1.5"><CheckCircle2 size={14} className="text-emerald-700" />{t}</span>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
