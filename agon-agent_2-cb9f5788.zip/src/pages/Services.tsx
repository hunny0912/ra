import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Search, X, Clock, Layers3, IndianRupee, CheckCircle2, CalendarCheck,
  ArrowRight, Flame, Phone, Calculator, ChevronDown,
} from 'lucide-react';
import { SERVICES, CATEGORIES, type Service } from '../data/services';
import { CLINIC } from '../lib/store';
import { PageHero } from '../components/ui';

export default function Services() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>('All');
  const [active, setActive] = useState<Service | null>(null);
  const [sessions, setSessions] = useState(4);
  const [calcService, setCalcService] = useState('');

  useEffect(() => {
    const s = params.get('service');
    if (s) setActive(SERVICES.find(x => x.id === s) ?? null);
    else setActive(null);
  }, [params]);

  const openService = (s: Service | null) => {
    const next = new URLSearchParams(params);
    if (s) next.set('service', s.id); else next.delete('service');
    setParams(next, { replace: true });
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return SERVICES.filter(s =>
      (category === 'All' || s.category === category) &&
      (!q || [s.name, s.hindi, s.tagline, s.category, s.description].join(' ').toLowerCase().includes(q)));
  }, [query, category]);

  const calc = SERVICES.find(s => s.id === calcService) ?? null;
  const calcTotal = calc ? calc.price * sessions : 0;
  const peelNote = calc && sessions >= 3 ? Math.round(calcTotal * 0.1) : 0;

  return (
    <div>
      <PageHero eyebrow="Treatments & Pricing" title={<>Honest prices,<br /><span className="italic text-gold">visible upfront</span></>} sub="Every treatment is doctor-prescribed, medically supervised and priced transparently. Tap any treatment for full details, inclusions and session plans." />

      {/* Search + category filter */}
      <div className="sticky top-16 z-30 bg-cream/90 backdrop-blur-xl border-b border-pine/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col sm:flex-row gap-3 sm:items-center">
          <label className="relative flex-1">
            <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search treatments — PRP, laser, peel, facial…"
              className="w-full h-11 rounded-full border border-pine/15 bg-sand pl-11 pr-10 text-sm outline-none focus:border-terra" aria-label="Search treatments" />
            {query && <button onClick={() => setQuery('')} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink/40 hover:text-ink"><X size={17} /></button>}
          </label>
          <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0 -mx-4 px-4 sm:mx-0 sm:px-0">
            {CATEGORIES.map(c => (
              <button key={c} onClick={() => setCategory(c)}
                className={`whitespace-nowrap rounded-full px-4 h-11 text-[12.5px] font-bold transition-all border ${category === c ? 'bg-pine text-cream border-pine' : 'bg-sand text-pine border-pine/15 hover:border-pine/40'}`}>
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid lg:grid-cols-12 gap-8">
        {/* Grid */}
        <div className="lg:col-span-8">
          {filtered.length === 0 && (
            <div className="rounded-3xl border border-dashed border-pine/25 bg-sand/50 p-12 text-center">
              <p className="font-display text-2xl text-pine">Nothing matched “{query}”</p>
              <p className="mt-2 text-sm text-ink/60">Try “hair”, “peel”, “laser”, “acne”, “facial”…</p>
              <button onClick={() => { setQuery(''); setCategory('All'); }} className="mt-4 rounded-full bg-pine text-cream px-6 py-2.5 text-sm font-bold">Clear filters</button>
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            {filtered.map(s => (
              <button key={s.id} onClick={() => openService(s)}
                className="group text-left rounded-3xl border border-pine/10 bg-sand p-5 flex flex-col hover:-translate-y-1 hover:shadow-card transition-all duration-300 relative">
                {s.popular && <span className="absolute top-4 right-4 inline-flex items-center gap-1 rounded-full bg-terra-soft text-terra-dark px-2.5 py-1 text-[9.5px] font-extrabold uppercase tracking-widest"><Flame size={10} />Popular</span>}
                <div className="h-11 w-11 rounded-2xl bg-pine flex items-center justify-center text-gold"><s.icon size={21} strokeWidth={1.8} /></div>
                <h3 className="mt-3.5 font-display font-semibold text-[17px] text-pine leading-snug">{s.name}</h3>
                <p className="text-[10.5px] font-semibold text-moss">{s.hindi}</p>
                <p className="mt-1.5 text-[12px] text-ink/65 leading-snug flex-1">{s.tagline}</p>
                <div className="mt-4 pt-3 border-t border-pine/10 flex items-center justify-between w-full">
                  <span className="text-pine font-extrabold text-[15px]">{s.priceNote && <span className="text-[9px] uppercase text-ink/50 align-middle mr-1">{s.priceNote}</span>}₹{s.price.toLocaleString('en-IN')}<span className="text-[10px] text-ink/50 font-semibold"> /session</span></span>
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-terra group-hover:gap-2 transition-all">Details <ArrowRight size={12} /></span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar: estimator + help */}
        <aside className="lg:col-span-4 space-y-5">
          <div className="rounded-3xl bg-pine text-cream p-6 shadow-soft sticky top-32">
            <p className="flex items-center gap-2 text-[10.5px] font-bold uppercase tracking-[0.2em] text-gold"><Calculator size={14} /> Treatment cost estimator</p>
            <h3 className="mt-2 font-display font-semibold text-xl">Plan your sessions</h3>
            <p className="mt-1 text-[12px] text-cream/65">Pick a treatment & sessions — get an instant estimate. 10% off multi-session plans.</p>
            <label className="block mt-4 text-[11px] font-bold text-cream/70">TREATMENT
              <span className="relative mt-1.5 block">
                <select value={calcService} onChange={e => setCalcService(e.target.value)}
                  className="w-full appearance-none h-11 rounded-xl bg-cream text-pine px-3.5 pr-9 text-[13px] font-semibold outline-none">
                  <option value="">Choose a treatment…</option>
                  {SERVICES.map(s => <option key={s.id} value={s.id}>{s.name} — ₹{s.price.toLocaleString('en-IN')}</option>)}
                </select>
                <ChevronDown size={16} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-pine" />
              </span>
            </label>
            {calc && (
              <>
                <label className="block mt-4 text-[11px] font-bold text-cream/70">SESSIONS: <span className="text-gold">{sessions}</span>
                  <input type="range" min={1} max={10} value={sessions} onChange={e => setSessions(+e.target.value)} className="mt-2 w-full accent-[#E9B44C]" aria-label="Number of sessions" />
                </label>
                <div className="mt-4 rounded-2xl bg-cream/10 border border-cream/15 p-4 text-[13px] space-y-1.5">
                  <div className="flex justify-between"><span className="text-cream/70">₹{calc.price.toLocaleString('en-IN')} × {sessions} sessions</span><span>₹{calcTotal.toLocaleString('en-IN')}</span></div>
                  {peelNote > 0 && <div className="flex justify-between text-gold"><span>Multi-session discount (10%)</span><span>− ₹{peelNote.toLocaleString('en-IN')}</span></div>}
                  <div className="flex justify-between border-t border-cream/15 pt-2 font-extrabold text-base"><span>Estimated total</span><span className="text-gold">₹{(calcTotal - peelNote).toLocaleString('en-IN')}</span></div>
                  <p className="text-[10px] text-cream/50 pt-1">*Indicative only. Exact plan & pricing confirmed after consultation. Consultation ₹500, adjusted against any treatment.</p>
                </div>
                <button onClick={() => navigate(`/book?service=${calc.id}`)} className="mt-4 w-full rounded-xl bg-terra py-3.5 font-bold text-cream flex items-center justify-center gap-2 hover:bg-terra-dark transition-colors"><CalendarCheck size={17} /> Book {calc.name.split(' ')[0]} — ₹{(calcTotal - peelNote).toLocaleString('en-IN')}</button>
              </>
            )}
            <a href={CLINIC.phoneHref} className="mt-3 flex items-center justify-center gap-2 rounded-xl border border-cream/20 py-3 text-[13px] font-bold text-cream/85 hover:text-gold hover:border-gold/40 transition-colors"><Phone size={15} /> Confused? Call Dr. Sneha: 092841 31821</a>
          </div>
        </aside>
      </div>

      {/* ===== Detail modal ===== */}
      <AnimatePresence>
        {active && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] bg-pine/70 backdrop-blur-sm" onClick={() => openService(null)} />
            <motion.div
              initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 60 }} transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              role="dialog" aria-modal="true" aria-label={active.name}
              className="fixed z-[61] inset-x-0 bottom-0 sm:inset-8 lg:inset-x-auto lg:left-1/2 lg:-translate-x-1/2 lg:w-[min(680px,94vw)] lg:top-1/2 lg:-translate-y-1/2 max-h-[92vh] overflow-y-auto bg-cream rounded-t-3xl sm:rounded-3xl shadow-soft">
              <div className="sticky top-0 bg-pine text-cream px-6 py-5 rounded-t-3xl sm:rounded-t-3xl flex items-start justify-between gap-4 z-10">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-2xl bg-gold/15 flex items-center justify-center text-gold"><active.icon size={24} /></div>
                  <div>
                    <h3 className="font-display font-semibold text-lg sm:text-xl leading-tight">{active.name}</h3>
                    <p className="text-[10.5px] text-gold/90 font-semibold">{active.hindi} · {active.category}</p>
                  </div>
                </div>
                <button onClick={() => openService(null)} aria-label="Close" className="p-2 rounded-full hover:bg-cream/10"><X size={22} /></button>
              </div>
              <div className="p-6">
                <p className="font-display italic text-terra text-[15px]">{active.tagline}</p>
                <p className="mt-2.5 text-[13.5px] leading-relaxed text-ink/80">{active.description}</p>

                <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-bold">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-sand border border-pine/10 px-3 py-1.5 text-pine"><Clock size={12} /> {active.duration} min per session</span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-sand border border-pine/10 px-3 py-1.5 text-pine"><Layers3 size={12} /> {active.sessions}</span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-gold-soft border border-gold/40 px-3 py-1.5 text-terra-dark"><IndianRupee size={12} />{active.priceNote ? ` ${active.priceNote}` : ''} ₹{active.price.toLocaleString('en-IN')} / session</span>
                </div>

                <p className="mt-5 text-[10.5px] font-bold uppercase tracking-[0.18em] text-moss">What’s included</p>
                <ul className="mt-2 grid sm:grid-cols-2 gap-2">
                  {active.includes.map(item => (
                    <li key={item} className="flex items-start gap-2 text-[12.5px] text-ink/80 leading-snug"><CheckCircle2 size={14} className="mt-0.5 shrink-0 text-emerald-700" />{item}</li>
                  ))}
                </ul>

                <button onClick={() => navigate(`/book?service=${active.id}`)}
                  className="mt-6 w-full rounded-2xl bg-terra py-4 font-extrabold text-cream flex items-center justify-center gap-2 hover:bg-terra-dark transition-colors text-[15px]">
                  <CalendarCheck size={19} /> Book {active.name} — ₹{active.price.toLocaleString('en-IN')}
                </button>
                <p className="mt-2 text-center text-[10.5px] text-ink/50">No advance payment · Consultation ₹500 adjusted on same-day treatment</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
