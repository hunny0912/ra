import {
  Sparkles, Zap, Scissors, CircleDot, Leaf, Syringe, Droplets, Sun, ScanFace, type LucideIcon,
} from 'lucide-react';

export interface Service {
  id: string;
  name: string;
  hindi: string;
  tagline: string;
  description: string;
  price: number;
  priceNote?: string;
  duration: number;
  sessions: string;
  category: 'Hair' | 'Skin' | 'Laser & Aesthetics';
  icon: LucideIcon;
  popular?: boolean;
  includes: string[];
}

export const SERVICES: Service[] = [
  {
    id: 'prp-hair', name: 'PRP Hair Regrowth Therapy', hindi: 'PRP हेयर थेरेपी',
    tagline: 'Your own blood, concentrated. Richer hair, naturally.',
    description: 'Platelet-Rich Plasma therapy uses growth factors from your own blood to reactivate dormant follicles, thicken thinning hair and slow hair fall — no surgery, no foreign substances.',
    price: 4500, duration: 60, sessions: '4–6 sessions · 4–6 weeks apart', category: 'Hair',
    icon: Droplets, popular: true,
    includes: ['Scalp analysis & trichoscan', 'Blood draw + centrifuge concentration', 'Micro-injection across thinning zones', 'Post-care serum & growth home-plan'],
  },
  {
    id: 'laser-hair-removal', name: 'Laser Hair Removal', hindi: 'लेज़र हेयर रिमूवल',
    tagline: 'Silk-smooth skin, permanently quiet follicles.',
    description: 'Triple-wavelength diode laser for all Indian skin types — underarms, face, full arms, legs, bikini or full body. Skin-cooling sapphire tip keeps it comfortable and fast.',
    price: 1200, priceNote: 'from', duration: 30, sessions: '6–8 sessions · 4–6 weeks apart', category: 'Hair',
    icon: Zap, popular: true,
    includes: ['Patch test & skin-type mapping', 'Pre-laser cooling gel', 'Triple-wavelength diode pass', 'Soothing recovery cream kit'],
  },
  {
    id: 'hydrafacial', name: 'Signature Hydrafacial', hindi: 'हाइड्राफेशियल',
    tagline: 'The 45-minute glass-skin reset.',
    description: 'Medical-grade deep cleanse, gentle acid peel, painless extraction and hyaluronic infusion in one seamless sitting. Zero downtime — walk out photo-ready.',
    price: 3500, duration: 45, sessions: 'Once a month for maintenance', category: 'Skin',
    icon: Sparkles, popular: true,
    includes: ['Deep cleanse + microderm tip exfoliation', 'Lactic-glycolic infusion peel', 'Painless vortex extraction', 'Hyaluronic + peptide antioxidant seal'],
  },
  {
    id: 'chemical-peel', name: 'Chemical Peel Program', hindi: 'केमिकल पील',
    tagline: 'Peel away dullness, spots and acne memories.',
    description: 'Dermatologist-supervised peels — salicylic, glycolic, TCA or yellow peel — customised to your concern: acne, pigmentation, melasma, tanning or open pores.',
    price: 2500, priceNote: 'from', duration: 30, sessions: '3–6 sessions · 3–4 weeks apart', category: 'Skin',
    icon: Leaf,
    includes: ['Skin assessment & peel selection', 'Pre-peel cleanse & degrease', 'Controlled layered application', 'Post-peel barrier repair kit'],
  },
  {
    id: 'acne-scar', name: 'Acne & Scar Revision', hindi: 'एक्ने एंड स्कार',
    tagline: 'Where acne ends, clear skin begins.',
    description: 'Combination protocol — subcision, microneedling RF, peels and prescription actives — designed around your skin. For active acne, hormonal acne and stubborn pitted scars.',
    price: 2000, priceNote: 'consult from', duration: 45, sessions: 'Customised · reviewed every visit', category: 'Skin',
    icon: CircleDot,
    includes: ['Detailed scar & pore mapping', 'Oral + topical prescription plan', 'In-clinic procedure (if required)', 'Monthly progress photography'],
  },
  {
    id: 'anti-aging', name: 'Wrinkles & Botox', hindi: 'रिंकल्स एंड बोटॉक्स',
    tagline: 'Time, negotiated gracefully.',
    description: 'FDA-approved botulinum toxin for expression lines, forehead and crow’s feet — plus collagen-stimulating HIFU and thread options for sagging skin.',
    price: 8000, priceNote: 'from', duration: 30, sessions: 'Every 4–6 months', category: 'Laser & Aesthetics',
    icon: ScanFace,
    includes: ['Facial movement assessment', 'FDA-approved botox units', 'Ice-numbing for comfort', '2-week review appointment'],
  },
  {
    id: 'fillers', name: 'Dermal Fillers & Lips', hindi: 'फिलर्स एंड लिप्स',
    tagline: 'Volume, where youth keeps it.',
    description: 'Hyaluronic-acid fillers for lips, cheeks, under-eye hollows and smile lines. Subtle, balanced, and reversible — results you see before you leave.',
    price: 15000, priceNote: 'from', duration: 45, sessions: 'Every 9–12 months', category: 'Laser & Aesthetics',
    icon: Syringe,
    includes: ['Symmetry & volume planning', 'Premium HA filler (1 ml)', 'Numbing cream + ice', 'Bruise-care guide & follow-up'],
  },
  {
    id: 'laser-carbon', name: 'Carbon Laser Facial', hindi: 'कार्बन लेज़र फेशियल',
    tagline: 'The celebrity “Hollywood peel”.',
    description: 'A carbon-milk mask + Q-switched laser pass vaporises oil, blackheads and dead cells while tightening pores and boosting collagen. Instant glow.',
    price: 3000, duration: 40, sessions: 'Once a month for maintenance', category: 'Laser & Aesthetics',
    icon: Sun, popular: true,
    includes: ['Skin prep & degrease', 'Medical carbon-lotion mask', 'Q-switched Nd:YAG laser pass', 'Calming aloe + sunscreen finish'],
  },
  {
    id: 'mesotherapy', name: 'Mesotherapy & Skin Boosters', hindi: 'मेसोथेरेपी',
    tagline: 'Vitamins, delivered exactly where skin craves them.',
    description: 'Micro-dosed cocktails of vitamins, hyaluronic acid and peptides injected into the dermis for hydration, glow, hair fall control and early ageing.',
    price: 4000, duration: 45, sessions: '3–4 sessions · 2–3 weeks apart', category: 'Skin',
    icon: Scissors,
    includes: ['Skin/hair concern mapping', 'Custom active-cocktail selection', 'Painless meso-injector technique', 'Home maintenance plan'],
  },
];

export const CATEGORIES = ['All', 'Hair', 'Skin', 'Laser & Aesthetics'] as const;
