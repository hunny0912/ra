export interface Review {
  id: number;
  name: string;
  initials: string;
  date: string;
  rating: number;
  service: string;
  text: string;
  color: string;
  verified: boolean;
}

export const REVIEWS: Review[] = [
  {
    id: 1, name: 'Priya Deshmukh', initials: 'PD', date: '2026-10-18', rating: 5, service: 'PRP Hair Treatment',
    text: 'After 3 sessions of PRP, my hair fall has reduced drastically and baby hair is visible along my hairline. Dr. Sneha explained every step patiently and never pushed unnecessary sessions. Highly recommend this clinic to anyone in Wakad!',
    color: '#C4552D', verified: true,
  },
  {
    id: 2, name: 'Rohit Kulkarni', initials: 'RK', date: '2026-10-05', rating: 5, service: 'Laser Hair Removal',
    text: 'Got my underarms and beard shaping laser done. Painless, quick and professional. The clinic is spotlessly clean and the staff makes you feel completely at ease. Pricing is very honest compared to other chains.',
    color: '#143C33', verified: true,
  },
  {
    id: 3, name: 'Sneha Patil', initials: 'SP', date: '2026-09-22', rating: 5, service: 'Hydrafacial',
    text: 'The signature hydrafacial is magic! My skin looked glass-like right after. The ambience is so calm and elegant — felt like a mini retreat, not a hospital. Will definitely keep coming.',
    color: '#C99A5B', verified: true,
  },
  {
    id: 4, name: 'Aditya Joshi', initials: 'AJ', date: '2026-09-11', rating: 5, service: 'Acne Treatment',
    text: 'I had severe hormonal acne for 2 years. Dr. Sneha diagnosed the root cause, put me on a realistic plan and within 8 weeks my skin was visibly clearer. She is an amazing listener — rare these days.',
    color: '#27594D', verified: true,
  },
  {
    id: 5, name: 'Meera Nair', initials: 'MN', date: '2026-08-28', rating: 5, service: 'Chemical Peel',
    text: 'Excellent doctor and very polite staff. The peel sessions completely removed my tanning and pigmentation from face and neck. 5 stars without a doubt — best skin clinic in Pimpri-Chinchwad.',
    color: '#A63F20', verified: true,
  },
  {
    id: 6, name: 'Vikram Shetty', initials: 'VS', date: '2026-08-14', rating: 5, service: 'Consultation',
    text: 'First visit for general skin consultation before my wedding. Dr. Sneha made a 3-month plan covering facials, peels and diet. Execution was on point and I looked my absolute best. Thank you!',
    color: '#4F7166', verified: true,
  },
  {
    id: 7, name: 'Kavya Rathore', initials: 'KR', date: '2026-07-30', rating: 5, service: 'Carbon Laser Facial',
    text: 'The Hollywood facial is addictive — instant glow and zero downtime. Appointment scheduling on call was super smooth and the clinic location par opposite PCMC School is very easy to find.',
    color: '#8FA89B', verified: true,
  },
  {
    id: 8, name: 'Ananya Iyer', initials: 'AI', date: '2026-07-15', rating: 5, service: 'PRP Hair Treatment',
    text: 'Was nervous about injections in the scalp, but Dr. Sneha made it completely painless. 4 sessions done, regrowth is clearly visible in photos. Charges are reasonable and results speak.',
    color: '#143C33', verified: true,
  },
];

export const SERVICE_OPTIONS = [...new Set(REVIEWS.map((r) => r.service))];
