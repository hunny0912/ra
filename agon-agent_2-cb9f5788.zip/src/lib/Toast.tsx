import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Info, X } from 'lucide-react';

interface Toast { id: number; title: string; desc?: string; kind: 'success' | 'info' }
interface ToastCtx { toast: (t: Omit<Toast, 'id'>) => void }
const Ctx = createContext<ToastCtx | null>(null);
let toastId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toast = useCallback((t: Omit<Toast, 'id'>) => {
    const id = ++toastId;
    setToasts((p) => [...p, { ...t, id }]);
    window.setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 4200);
  }, []);
  return (
    <Ctx.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-24 right-4 sm:right-6 z-[80] flex flex-col gap-2 w-[min(92vw,360px)]">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id} layout initial={{ opacity: 0, x: 80 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 80 }}
              className="flex items-start gap-3 rounded-2xl border border-pine/10 bg-pine text-cream px-4 py-3 shadow-soft"
            >
              {t.kind === 'success'
                ? <CheckCircle2 size={20} className="mt-0.5 shrink-0 text-gold" />
                : <Info size={20} className="mt-0.5 shrink-0 text-gold" />}
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-sm leading-snug">{t.title}</p>
                {t.desc && <p className="text-xs text-cream/70 mt-0.5 leading-snug">{t.desc}</p>}
              </div>
              <button aria-label="Dismiss" onClick={() => setToasts((p) => p.filter((x) => x.id !== t.id))}
                className="text-cream/50 hover:text-cream transition-colors"><X size={16} /></button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useToast outside ToastProvider');
  return ctx.toast;
}
