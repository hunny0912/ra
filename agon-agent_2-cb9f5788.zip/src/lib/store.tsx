import {
  createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode,
} from 'react';

export type BookingStatus = 'upcoming' | 'completed' | 'cancelled';

export interface Booking {
  id: string;
  serviceId: string;
  serviceName: string;
  servicePrice: number;
  duration: number;
  dateISO: string; // yyyy-mm-dd
  slot: string; // e.g. "11:30 AM"
  name: string;
  phone: string;
  concern: string;
  firstVisit: boolean;
  status: BookingStatus;
  createdAt: number;
}

interface BookingContextValue {
  bookings: Booking[];
  addBooking: (b: Omit<Booking, 'id' | 'createdAt' | 'status'>) => Booking;
  cancelBooking: (id: string) => void;
  rescheduleBooking: (id: string, dateISO: string, slot: string) => void;
}

const BookingContext = createContext<BookingContextValue | null>(null);
const KEY = 'lhs_bookings_v1';

const SEED: Booking[] = [
  {
    id: 'LH-240618-042', serviceId: 'prp-hair', serviceName: 'PRP Hair Regrowth Therapy',
    servicePrice: 4500, duration: 60, dateISO: '2026-11-04', slot: '11:30 AM',
    name: 'You', phone: '98XXXXXX12', concern: 'Hair fall & thinning crown',
    firstVisit: false, status: 'upcoming', createdAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
  },
];

function load(): Booking[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as Booking[];
  } catch { /* ignore */ }
  return SEED;
}

export function BookingProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>(() => (typeof window === 'undefined' ? SEED : load()));

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(bookings)); } catch { /* ignore */ }
  }, [bookings]);

  const addBooking = useCallback<BookingContextValue['addBooking']>((b) => {
    const booking: Booking = {
      ...b,
      id: 'LH-' + Date.now().toString(36).toUpperCase().slice(-6) + '-' + String(Math.floor(Math.random() * 900) + 100),
      status: 'upcoming',
      createdAt: Date.now(),
    };
    setBookings((prev) => [booking, ...prev]);
    return booking;
  }, []);

  const cancelBooking = useCallback((id: string) => {
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'cancelled' } : b)));
  }, []);

  const rescheduleBooking = useCallback((id: string, dateISO: string, slot: string) => {
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, dateISO, slot } : b)));
  }, []);

  const value = useMemo(
    () => ({ bookings, addBooking, cancelBooking, rescheduleBooking }),
    [bookings, addBooking, cancelBooking, rescheduleBooking],
  );
  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBookings() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error('useBookings must be used within BookingProvider');
  return ctx;
}

/* ---------- clinic schedule helpers ---------- */

export const CLINIC = {
  name: 'Lazy Hair and Skin Clinic',
  hindi: 'लेजी हेयर एंड स्किन क्लिनिक',
  category: 'Dermatologist',
  phone: '092841 31821',
  phoneHref: 'tel:+919284131821',
  whatsappHref: 'https://wa.me/919284131821?text=' + encodeURIComponent('Hi Lazy Hair and Skin Clinic! I would like to book an appointment.'),
  address: 'Sanskriti Arcade, 205, Chatrapati Chowk Rd, opp. PCMC School, Kaspate Wasti, Wakad, Pimpri-Chinchwad, Maharashtra 411057',
  mapsLink: 'https://www.google.com/maps/search/' + encodeURIComponent('Lazy Hair and Skin Clinic Wakad'),
  embedSrc: 'https://maps.google.com/maps?q=Lazy%20Hair%20and%20Skin%20Clinic%20Wakad&t=&z=16&ie=UTF8&iwloc=&output=embed',
  plusCode: 'HQWF+2G Wakad, Pimpri-Chinchwad, Maharashtra',
  rating: 5.0,
  reviewCount: 8,
  hours: { open: 10 * 60 + 30, close: 19 * 60 }, // 10:30 AM – 7:00 PM
};

export function isOpenNow(d = new Date()): boolean {
  const mins = d.getHours() * 60 + d.getMinutes();
  return mins >= CLINIC.hours.open && mins < CLINIC.hours.close;
}

export function todayISO(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function fmtDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

/** Deterministic pseudo-random slot availability so past dates are fully booked. */
export function slotAvailability(dateISO: string, slot: string): 'open' | 'few' | 'full' {
  const today = todayISO();
  if (dateISO < today) return 'full';
  let h = 2166136261;
  const s = dateISO + '|' + slot;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const v = (h >>> 0) % 100;
  if (v < 22) return 'full';
  if (v < 45) return 'few';
  return 'open';
}

export function generateSlots(): string[] {
  const slots: string[] = [];
  for (let mins = CLINIC.hours.open; mins < CLINIC.hours.close; mins += 30) {
    const h24 = Math.floor(mins / 60);
    const m = mins % 60;
    const ampm = h24 >= 12 ? 'PM' : 'AM';
    const h12 = ((h24 + 11) % 12) + 1;
    slots.push(`${h12}:${String(m).padStart(2, '0')} ${ampm}`);
  }
  return slots;
}

export function nextDays(count: number): { iso: string; weekday: string; day: number; month: string; isToday: boolean }[] {
  const out = [];
  const today = todayISO();
  const d = new Date();
  for (let i = 0; i < count; i++) {
    const dt = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i);
    const pad = (n: number) => String(n).padStart(2, '0');
    const iso = `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`;
    out.push({
      iso,
      weekday: dt.toLocaleDateString('en-IN', { weekday: 'short' }),
      day: dt.getDate(),
      month: dt.toLocaleDateString('en-IN', { month: 'short' }),
      isToday: iso === today,
    });
  }
  return out;
}
