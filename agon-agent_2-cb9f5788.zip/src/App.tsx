import { useEffect, useState } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { MessageCircle, Phone, CalendarCheck, ChevronUp, Star, X } from 'lucide-react';
import { BookingProvider, CLINIC } from './lib/store';
import { ToastProvider } from './lib/Toast';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Services from './pages/Services';
import Reviews from './pages/Reviews';
import About from './pages/About';
import Contact from './pages/Contact';
import Book from './pages/Book';
import MyAppointments from './pages/MyAppointments';

function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-6 bg-cream">
      <p className="font-display font-black text-8xl text-pine/10">404</p>
      <h1 className="font-display font-semibold text-3xl text-pine -mt-6">This page slipped away</h1>
      <p className="mt-2 text-ink/60 max-w-sm">The page you’re looking for doesn’t exist — but clear skin does.</p>
      <Link to="/" className="mt-6 rounded-full bg-terra text-cream px-6 py-3 font-bold hover:bg-terra-dark transition-colors">Back to home</Link>
    </div>
  );
}

function FloatingActions() {
  const [showTop, setShowTop] = useState(false);
  const [waOpen, setWaOpen] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 420);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => { setWaOpen(false); }, [pathname]);

  return (
    <div className="fixed z-[70] right-4 sm:right-6 bottom-5 flex flex-col items-end gap-3">
      {/* Scroll to top */}
      <AnimatePresence>
        {showTop && (
          <motion.button initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.6 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Scroll to top"
            className="h-11 w-11 rounded-full bg-cream border border-pine/20 shadow-card flex items-center justify-center text-pine hover:bg-sand transition-colors">
            <ChevronUp size={20} />
          </motion.button>
        )}
      </AnimatePresence>

      {/* WhatsApp quick chat bubble */}
      <AnimatePresence>
        {waOpen && (
          <motion.div initial={{ opacity: 0, y: 16, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.9 }}
            className="w-[min(320px,88vw)] rounded-3xl overflow-hidden shadow-soft border border-pine/10">
            <div className="bg-[#075E54] px-4 py-3 flex items-center gap-3">
              <img src="/favicon.svg" alt="" className="h-10 w-10 rounded-full bg-cream p-0.5" />
              <div className="min-w-0 flex-1">
                <p className="text-cream text-[13px] font-bold leading-tight">Lazy Hair &amp; Skin Clinic</p>
                <p className="text-[10px] text-[#8FE3B4] font-semibold flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-[#25D366]" />Typically replies within minutes</p>
              </div>
              <button onClick={() => setWaOpen(false)} aria-label="Close chat" className="p-1.5 text-cream/80 hover:text-cream"><X size={18} /></button>
            </div>
            <div className="bg-[#ECE5DD] p-4">
              <div className="max-w-[85%] rounded-2xl rounded-tl-md bg-white px-3.5 py-2.5 shadow-sm">
                <p className="text-[12.5px] leading-snug text-ink/90">Hi there! Want to ask about a treatment or book your visit? Tap below to chat with us on WhatsApp.</p>
                <p className="mt-1 text-right text-[9px] text-ink/45">now</p>
              </div>
              <a href={CLINIC.whatsappHref} target="_blank" rel="noreferrer"
                className="mt-3 flex items-center justify-center gap-2 rounded-full bg-[#25D366] py-2.5 text-[13px] font-extrabold text-[#075E54] hover:brightness-105 transition">
                <MessageCircle size={16} /> Open WhatsApp chat
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Book FAB (mobile) */}
      <button onClick={() => navigate('/book')} aria-label="Book appointment"
        className="sm:hidden h-14 w-14 rounded-full bg-terra text-cream shadow-[0_14px_34px_-8px_rgba(196,85,45,0.65)] flex items-center justify-center hover:bg-terra-dark transition-colors">
        <CalendarCheck size={24} />
      </button>

      {/* WhatsApp FAB */}
      <button onClick={() => setWaOpen(v => !v)} aria-label="Chat on WhatsApp"
        className="relative h-14 w-14 sm:h-16 sm:w-16 rounded-full bg-[#25D366] text-[#075E54] shadow-[0_14px_34px_-8px_rgba(37,211,102,0.65)] flex items-center justify-center hover:scale-105 active:scale-95 transition-transform">
        <span aria-hidden className="absolute inset-0 rounded-full bg-[#25D366] animate-ping-dot" />
        <MessageCircle size={27} className="relative" strokeWidth={2.2} />
      </button>

      {/* Call FAB (desktop) */}
      <a href={CLINIC.phoneHref} aria-label="Call the clinic"
        className="hidden sm:flex h-16 w-16 rounded-full bg-pine text-gold shadow-soft items-center justify-center hover:scale-105 transition-transform">
        <Phone size={26} strokeWidth={2.2} />
      </a>
    </div>
  );
}

function GoogleRatingBadge() {
  return (
    <div className="fixed z-[60] left-4 sm:left-6 bottom-5 hidden md:flex items-center gap-2.5 rounded-2xl bg-cream/95 backdrop-blur border border-pine/15 shadow-card px-4 py-2.5">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#4285F4] font-display font-black text-lg text-white">G</span>
      <span>
        <span className="flex items-center gap-1.5 text-[12px] font-extrabold text-pine leading-none"><Star size={12} className="fill-gold text-gold" />5.0 · Excellent</span>
        <span className="mt-1 block text-[9.5px] font-semibold text-ink/55">Based on 8 Google reviews</span>
      </span>
    </div>
  );
}

function ScrollTopOnRoute() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

export default function App() {
  return (
    <ToastProvider>
      <BookingProvider>
        <HashRouter>
          <ScrollTopOnRoute />
          <div className="min-h-screen bg-cream font-sans text-ink antialiased flex flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/services" element={<Services />} />
                <Route path="/reviews" element={<Reviews />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/book" element={<Book />} />
                <Route path="/my-appointments" element={<MyAppointments />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
            <FloatingActions />
            <GoogleRatingBadge />
          </div>
        </HashRouter>
      </BookingProvider>
    </ToastProvider>
  );
}
